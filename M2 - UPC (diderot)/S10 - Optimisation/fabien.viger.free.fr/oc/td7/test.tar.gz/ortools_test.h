#include <vector>

using std::vector;

vector<double> MonPremierSolveur(int n);


