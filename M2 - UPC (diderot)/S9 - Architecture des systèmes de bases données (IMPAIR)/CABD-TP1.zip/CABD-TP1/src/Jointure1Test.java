import static org.junit.Assert.*;

import java.util.Vector;

import org.junit.Test;

/**lancer cette classe pour tester le resultat de Jointure1*/
public class Jointure1Test {
	/**compare T.txt, qui a ete genere par Jointure1
	 * avec Ttest.txt, resultat attendu ecrit a la main*/
	@Test
	public void testJointure1(){
		String fichierResultat = "T.txt";
		String fichierTemoin = "Ttest.txt";
		Vector<Character> tableT = Jointure1.lireTable(fichierResultat);
		Vector<Character> tableTbis = Jointure1.lireTable(fichierTemoin);
		assertEquals(tableT, tableTbis);
		System.out.println(fichierResultat+" et "+fichierTemoin+" sont bien identiques");
	}	
}