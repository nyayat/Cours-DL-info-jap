import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Vector;

/**
* TP n�: 1
*
* Titre du TP : Jointure
*
* Date : 2 octobre 2010
*
* Nom : ...
* Prenom : ...
*
* Remarques : Lancer d'abord Jointure1 pour generer T.txt, 
* 			puis lancer Jointure1Test pour le comparer a Ttest.txt
*/

public class Jointure1 {

	/**transforme le fichier fileIn en vecteur de char*/
	public static Vector<Character> lireTable(String fileIn){
		/**chaque ligne de fileIn est mise dans le vecteur table*/
		Vector<Character> table=new Vector<Character>();
		try{
			InputStream ips=new FileInputStream(fileIn); 
			InputStreamReader ipsr=new InputStreamReader(ips);
			BufferedReader br=new BufferedReader(ipsr);
			String ligne;
			while ((ligne=br.readLine())!=null)
				if(ligne.length() > 0) //pour ignorer les eventuelles lignes vides
					table.add(ligne.charAt(0));
			br.close();
			System.out.println("on a bien lu "+fileIn);
		}
		catch (Exception e){
			System.out.println(e.toString());
		}
		return table;
	}

	/**renvoie la jointure de table1 et table2 
	 * (version simple : ne supprime pas les doublons)*/
	public static Vector<Character> jointure1(Vector<Character> table1, Vector<Character> table2){
		Vector<Character> res = new Vector<Character>();
		for(int i=0; i<table1.size(); i++)
			for(int j=0; j<table2.size(); j++)
				if(table1.elementAt(i).equals(table2.elementAt(j))) //si 2 elements sont egaux
					res.add(table1.elementAt(i)); //on les ajoute a la jointure
		return res;
	}

	/**ecrit le vecteur table dans un fichier fileOut*/
	public static void ecrireFichier(Vector<Character> table, String fileOut){
		/**on recopie le vecteur table dans un String chaine*/
		String chaine="";
		for(int i=0; i<table.size(); i++)
			chaine += (table.elementAt(i)+"\n");
		/**on ecrit chaine dans le fichier fileOut*/
		try{
			FileWriter fw = new FileWriter (fileOut);
			BufferedWriter bw = new BufferedWriter(fw);
			PrintWriter fichierSortie = new PrintWriter(bw); 
			fichierSortie.println (chaine); 
			fichierSortie.close();
			System.out.println("Le fichier " + fileOut + " a bien �t� cr�� !"); 
		}
		catch (Exception e){
			System.out.println(e.toString());
		}		
	}


	public static void main(String[] args){
		Vector<Character> tableR = lireTable("R.txt");
		Vector<Character> tableS = lireTable("S.txt");
		
		Vector<Character> tableT = jointure1(tableR, tableS);

		ecrireFichier(tableT, "T.txt");
	}
}