Récapitulatif des tâches pour le projet de TransProg 2022
=========================================================

Projet faisable par groupe de deux au plus.
Date limite de rendu : 14/3/2022 au soir

Soutenances de projet le 15/3/2022 en 2003.
Le [framadate](https://sdstm.math-info-paris.cnrs.fr/shared/c2ew4GQYpddmMNGgH_cZbZr-MXanokhNzyTNYVb0RE4) pour choisir son créneau.

Ce projet comporte deux parties. Terminer d'abord l'interpréteur `FopixInterp` est recommandé, mais pas obligatoire.

## Partie 1 : compilation directe de Fopix vers Javix

Cette partie nécessite de compléter le fichier suivant:

- [Fopix2Javix](src/main/scala/trac/transl/Fopix2Javix.scala)

Il est normal que les fichiers `.j` obtenus lors de cette partie ne donnent pas des `.class` directement acceptés par le validateur de la JVM. Ils seront donc à lancer via `java -noverify`.

## Partie 2 : compilation par CPS de Fopix vers Javix

Cette partie nécessite de compléter les fichiers suivants:

- [Fopix2Anfix](src/main/scala/trac/transl/Fopix2Anfix.scala)
- [Anfix2Kontix](src/main/scala/trac/transl/Anfix2Kontix.scala)
- [Kontix2Javix](src/main/scala/trac/transl/Kontix2Javix.scala)

Pour les différencier des fichiers obtenus en partie 1, les fichiers produits dans cette partie 2 seront appelés `.k` même s'il s'agit toujours de fichiers destinés à l'assembleur `jasmin`. Cette fois-ci, les `.class` correspondant devront pouvoir être exécutés via `java` (sans le `-noverify`). Attention alors à bien calculer et indiquer la hauteur de pile nécessaire dans votre programme.

## Dépôts git pris en compte pour le rendu de projet

Vous avez jusqu'au 1/3/2022 pour me rendre accessible votre fork de `letouzey/transprog-2022` sur le serveur gaufre.
Attention vos forks doivent être rendu **privés** dès leur création. Utiliser un seul fork par groupe. 
Me contacter si votre dépôt sur le serveur gaufre n'est pas déjà dans la liste suivante :

- dupuy/transprog-2022
- fidalgo/transprog-2022
- hadded/transprog-2022
- lebail/transprog-2022
- tulisz/transprog-2022
- rsmouki/transprog-2022
- voltevie/transprog-2022
- feauxdel/transprog-2022

