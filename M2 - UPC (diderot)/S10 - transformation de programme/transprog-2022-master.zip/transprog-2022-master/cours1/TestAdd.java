public class TestAdd {
    public static void main(String[] args) {
	int a = Integer.parseInt(args[0]);
	int b = Integer.parseInt(args[1]);
	int sum = AddFunction.addSum(a,b);
	System.out.println("The sum of the numbers from " + a +
			   " to " + b + " is " + sum);
	//	sum = Add.addSum(a,b);
	//System.out.println("The sum of the numbers from " + a +
	//		   " to " + b + " is " + sum);
    }
}
