
/* This module implements a translation from Fopix to Anfix */

// TODO : To finish !!

package trac.transl

object Fopix2Anfix {

import trac._
import trac.fopix.{AST=>S}
import trac.anfix.{AST=>T}

def trans(p:S.Program) : T.Program = {
  List()
}

}
