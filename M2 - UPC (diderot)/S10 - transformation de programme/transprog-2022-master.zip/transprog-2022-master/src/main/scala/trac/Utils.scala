
package trac

class Invalid(s:String) extends Exception(s){}  
