package fr.irif.zielonka.exam2022session1grb

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class Mails (
    @PrimaryKey(autoGenerate = true)
    val  id: Long = 0,
    var  nom: String,
    var  mail: String
)