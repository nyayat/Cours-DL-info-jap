package fr.irif.zielonka.exam2022session1grb

import androidx.lifecycle.LiveData
import androidx.room.*

data class MailItem(
    var nom : String,
    var mail : String
)

data class IdMail(
    val id: Long
)

@Dao
interface MonDao {

   @Insert(entity=Mails::class)
   fun insererAnnuaire( annuaireItem : MailItem ) : Long

   @Query( "DELETE FROM Mails")
   fun removeAllFromAnnuaire()

   @Delete(entity=Mails::class)
   fun deleteAnnuaire( idAnnuaire: IdMail)

   @Update
   fun updateAnnuaire( annuaire: Mails )

   @Query( "SELECT * FROM Mails")
   fun getAnnuaire(): LiveData<List<Mails>>

   @Query( "SELECT * FROM Mails WHERE lower(nom) LIKE lower(:pref) ||  '%'")
   fun getAnnuaireParNom( pref: String ): LiveData<List<Mails>>
}