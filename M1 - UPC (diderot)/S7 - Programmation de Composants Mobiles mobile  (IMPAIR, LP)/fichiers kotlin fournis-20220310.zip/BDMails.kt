package fr.irif.zielonka.exam2022session1grb

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
@Database(entities=[Mails::class], version = 1)
abstract class BDMails : RoomDatabase() {
    abstract fun monDao(): MonDao

    companion object {
        @Volatile
        private var instance: BDMails? = null

        fun getDatabase( context : Context): BDMails{
            if( instance != null )
                return instance!!
            val db = Room.databaseBuilder( context.applicationContext,
                BDMails::class.java ,
            "annuaire")
                .fallbackToDestructiveMigration() /* bd détruite si on change la version */
                .build()
            instance = db
            return instance!!
        }
    }
}