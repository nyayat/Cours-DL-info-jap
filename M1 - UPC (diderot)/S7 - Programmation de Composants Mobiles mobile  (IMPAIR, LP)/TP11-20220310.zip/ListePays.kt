package fr.uparis.eugene.tp11

object ListePays {
    var liste: MutableList<Pays> = mutableListOf(
        Pays("France", "Paris"),
        Pays("Espagne", "Madrid"),
        Pays("Italie", "Rome"),
        Pays("Belgique", "Bruxelles"),
        Pays("Pays-Bas", "Amsterdam"),
        Pays("Portugal", "Lisbonne"),
        Pays("Japon", "Tokyo"),
        Pays("Etats-Unis", "Washington"),
        Pays("Argentine", "Buenos Aires"),
        Pays("Mexique", "Mexico"),
        Pays("Algérie", "Alger"),
        Pays("Mali", "Bamako"),
        Pays("Cambodge", "Phnom Penh"),
        Pays("Pérou", "Lima"),
        Pays("Rwanda", "Kigali"),
        Pays("Grande-Bretagne", "Londres")
    )
}