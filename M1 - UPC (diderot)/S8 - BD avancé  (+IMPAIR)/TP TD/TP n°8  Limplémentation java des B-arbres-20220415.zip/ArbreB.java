import java.lang.Comparable;
import java.util.AbstractMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

/**
 * Une implémentation des arbres B+ sans doublons. Les clefs sont
 * triées à l'aide de l'ordre naturel.
 */
public class ArbreB<K extends Comparable<K>, V> {
    /** Le nombre <em>n</em> associé à l'arbre B+. */
    private int degre;
    /** La racine de l'arbre B+. */
    private Noeud<K,V> racine;

    /**
     * Construit un nouvel arbre B+ vide qui utilise l'ordre naturel
     * sur ses clefs.
     * @param degre Le nombre ≥ 2 associé à l'arbre.
     */
    public ArbreB(int degre){
        assert(degre > 1);
	this.degre = degre;
	this.racine = null;
    }

    /**
     * Retourne une représentation de l'arbre comme une chaîne de
     * caractères.
     * @return l'arbre comme une chaîne de caractères
     */
    public String toString() {
        if (racine == null)
            return "Ø\n";
        else
            return racine.affiche("");
    }
    
    /**
     * Associe la valeur donnée à la clef dans l'arbre. Si l'arbre
     * contenait déjà cette clef, l'ancienne valeur est remplacée.
     * @param clef la clef
     * @param valeur la valeur
     * @throws NullPointerException si la clef est nulle
     */
    public void put(K clef, V valeur) {
        /* étapes 1, 2 et 3 : à compléter */
    }
    
    /**
     * Retourne le noeud de l'arbre le plus éloigné de la racine qui
     * contient une clef maximale plus petite ou égale à la clef
     * fournie, ou {@code null} si l'arbre est vide.
     * @param clef la clef recherchée
     * @return le noeud d'insertion pour la clef, ou {@code null} si
     *         l'arbre est vide
     * @throws NullPointerException si la clef est nulle
     */
    final Noeud<K,V> noeud(K clef) {
        if (racine != null)
            return racine.noeud(clef);
        else
            return null;
    }

    /**
     * Retourne l'entrée de l'arbre de clef maximale plus petite ou
     * égale à la clef fournie, ou {@code null} si une telle entrée
     * n'existe pas dans l'arbre.
     * @param clef la clef recherchée
     * @return l'entrée de clef maximale plus petite ou égale à la
     *         clef fournie, ou {@code null} une telle entrée n'existe
     *         pas
     * @throws NullPointerException si la clef est nulle
     */
    public Map.Entry<K,V> floorEntry(K clef) {
        return noeud(clef).entree(clef);
    }

    //---------------------------------------------------------- tests
    
    /**
     * Méthode de test. À décommenter au fur et à mesure de
     * l'avancement du TP.
     */
    public static void main(String[] args) {
        ArbreB<Integer,String> a = new ArbreB<Integer,String>(3);
	System.out.println("0. arbre initial vide :");
        System.out.println(a);
        // // sous-étape 1
	// System.out.println("1. ajout de 10 :");
	// a.put(new Integer(10), "j");
        // System.out.println(a);
	// // sous-étape 2
        // System.out.println("2. ajout de 18, 7 :");
	// a.put(new Integer(18), "r");
        // a.put(new Integer(7), "g");
        // System.out.println(a);
	// // sous-étape 3
	// System.out.println("3. ajout avec éclatement d'une feuille : ajout de 5 :");
	// a.put(new Integer(5), "e");
        // System.out.println(a);
        // // sous-étape 4
	// System.out.println("4. ajout après éclatement : ajout de 15 et 9 :");
	// a.put(new Integer(15), "o");
	// a.put(new Integer(9), "i");
        // System.out.println(a);
	// // sous-étape 5
	// System.out.println("5. nouvel éclatement d'une feuille : ajout de 20 :");
	// a.put(new Integer(20), "t");
        // System.out.println(a);
	// System.out.println("5. ajout de 2 et 17 :");
	// a.put(new Integer(2), "b");
	// a.put(new Integer(17), "q");
        // System.out.println(a);
	// // sous-étape 6
	// System.out.println("6. éclatement d'un nœud interne : ajout de 11 :");
       	// a.put(new Integer(11),"k");
        // System.out.println(a);
        
	// System.out.println("ajout de 1, 23, 16, 4, 13 :");
       	// a.put(new Integer(1),  "a");
        // a.put(new Integer(23), "w");
        // a.put(new Integer(16), "p");
        // a.put(new Integer(4),  "d");
        // a.put(new Integer(13), "m");
        // System.out.println(a);
	// System.out.println("ajout de 22, 3 :");
	// a.put(new Integer(22),"v");
	// a.put(new Integer(3),"c");
        // System.out.println(a);
	// System.out.println("nouvel éclatement d'un nœud interne : ajout de 14 :");
	// a.put(new Integer(14), "n");
        // System.out.println(a);
        
	// System.out.println("ajout de 6, 24, 12, 8, 26 :");
	// a.put(new Integer(6),"f"); 	
        // a.put(new Integer(24),"x");	
        // a.put(new Integer(12),"l");	
        // a.put(new Integer(8),"h");	
        // a.put(new Integer(26),"z");
        // System.out.println(a);

        // // recherche
        // System.out.println("recherche de 23 : "
        //                    +a.floorEntry(new Integer(23)));
        // System.out.println("recherche de 24 : "
        //                    +a.floorEntry(new Integer(24)));
        // System.out.println("recherche de 25 : "
        //                    +a.floorEntry(new Integer(25)));
	// System.out.println("ajout de 25 :");
        // a.put(new Integer(25),"y"); 
        // System.out.println(a);		
	// System.out.println("ajout de 19 :");
	// a.put(new Integer(19),"s");
        // System.out.println(a);		
	// System.out.println("ajout de 21 :");
	// a.put(new Integer(21),"u");
        // System.out.println(a);
    }
    
    //---------------------------------------------------------- nœuds
    
    /**
     * Un nœud abstrait d'un arbre B+.
     */
    static abstract class Noeud<K extends Comparable<K>,V> {
        /** Le nombre <em>n</em> associé à l'arbre. */
        int degre;
        /** Les clefs du nœud. */
        List<K> clefs;
        
        public Noeud (int degre) {
            this.degre = degre;
            // une marge pour avoir des nœuds temporairement plus grands
            final Vector<K> v = new Vector<K>(degre+1);
            v.setSize(degre+1);
            v.set(degre, null);
            this.clefs = v;
        }

        /**
         * Retourne l'indice i maximal tel que clefs.get(i) ≤ clefs.
         * @param clef une clef
         * @return l'indice maximal d'une clef inférieure ou égale à
         *         la clef fournie, ou {@code -1} si toutes les clefs
         *         sont strictement supérieures
         */
        int index(K clef) {
            /* étape 0 : à compléter */
            return 0;
        }
        
        /**
         * Associe la valeur donnée à la clef dans l'arbre. Si l'arbre
         * contenait déjà cette clef, l'ancienne valeur est remplacée.
         * @param clef la clef
         * @param valeur la valeur
         * @return un nœud à ajouter au nœud courant s'il a fallu
         *         éclater un noeud fils et {@code null} sinon
         * @throws NullPointerException si la clef est nulle
         */
        abstract Map.Entry<K,Noeud<K,V>> ajoute(K clef, V valeur);
        
        /**
         * Retourne le nœud de l'arbre le plus éloigné de la racine qui
         * contient une clef maximale plus petite ou égale à la clef
         * fournie.
         * @param clef la clef recherchée
         * @return le nœud d'insertion pour la clef
         * @throws NullPointerException si la clef est nulle
         */
        abstract Noeud<K,V> noeud(K clef);
        /**
         * Si {@this} est une feuille, retourne l'entrée de clef
         * maximale plus petite ou égale à la clef fournie.
         * @param clef la clef recherchée
         * @return l'entrée de clef maximale plus petite ou égale à la
         *         clef fournie si {@code this} est une feuille, ou
         *         {@code null} si {@code this} est un nœud interne
         */
        abstract Map.Entry<K,V> entree(K clef);

        /**
         * Retourne une représentation textuelle du nœud et de ses descendants.
         */
        abstract String affiche(String indent);
    }

    /**
     * Un nœud interne d'un arbre B+. Invariant des nœuds internes :
     * si {@code clefs.get(i) != null}, alors {@code enfants.get(i) != null}
     * et {@code enfants.get(i+1) != null}.
     */
    static final class NoeudInterne<K extends Comparable<K>,V>
        extends Noeud<K,V> {
        private List<Noeud<K,V>> enfants;
        
        public NoeudInterne (int degre) {
            super(degre);
            // une marge pour avoir des nœuds temporairement plus grands
            final Vector<Noeud<K,V>> v = new Vector<Noeud<K,V>>(degre + 2);
            v.setSize(degre + 2);
            this.enfants = v;
        }

        Map.Entry<K,Noeud<K,V>> ajoute(K clef, V valeur) {
            /* étapes 4, 5 et 6 : à compléter */
            return null;
        }
        Noeud<K,V> noeud(K clef) {
            /* recherche : à compléter */
            return null;
        }
        Map.Entry<K,V> entree(K clef) {
            /* recherche : à compléter */
            return null;
        }
        
        String affiche(String indent) {
            String ret = "";
            int i = 0;
            ret += enfants.get(0).affiche(indent + "  ");
            while(i <= degre && clefs.get(i) != null){
                ret += indent + clefs.get(i) + "\n";
                ret += enfants.get(i+1).affiche(indent + "  ");
                i++;
            }
            return ret;
        }
    }

    /**
     * Une feuille d'un arbre B+. Invariant des feuilles : si
     * {@code clefs.get(i) != null} alors {@code elements.get(i) != null}.
     */
    static final class Feuille<K extends Comparable<K>,V>
        extends Noeud<K,V> {
        private List<V> elements;
        private Noeud suivant;
        
        public Feuille (int degre) {
            super(degre);
            // une marge pour avoir des feuilles temporairement plus grandes
            final Vector<V> v = new Vector<V>(degre+1);
            v.setSize(degre+1);
            this.elements = v;
            this.suivant = null;
        }

        Map.Entry<K,Noeud<K,V>> ajoute(K clef, V valeur) {
            /* étapes 2 et 3 : à compléter */
            return null;
        }
        Noeud<K,V> noeud(K clef) {
            /* recherche : à compléter */
            return null;
        }
        Map.Entry<K,V> entree(K clef) {
            /* recherche : à compléter */
            return null;
        }
        
        String affiche(String indent) {
            String ret = indent;
            if (null == clefs.get(0))
                return ret+"ø\n";
            else
                ret += clefs.get(0) + "," + elements.get(0);
            int i = 1;
            while(i <= degre && clefs.get(i) != null){
                ret += " " + clefs.get(i) + "," + elements.get(i);
                i++;
            }
            return ret+"\n";
        }
    }
}
