--
-- CREATION DE LA BASE DES comptes
--

DROP TABLE IF EXISTS comptes;
DROP TABLE IF EXISTS clients;	
DROP TABLE IF EXISTS resa;

CREATE TABLE clients (
     numclient serial PRIMARY KEY,
     nom varchar(20),
     prenom varchar(20)
);

CREATE TABLE comptes (
     numcompte serial PRIMARY KEY,
     numclient int REFERENCES clients,
     solde numeric(10,2)
);

--réservation théatre
CREATE TABLE resa (
     numplace serial PRIMARY KEY,
     nomclient text DEFAULT NULL, --si NULL place non réservées
     prix int
);

--peupler la table

insert into clients (nom, prenom) values ('Duval','Albert');
insert into clients (nom, prenom) values ('Durand','Barbara');
insert into clients (nom, prenom) values ('THEATRE','');

insert into comptes (numclient, solde) values (1, 100);
insert into comptes (numclient, solde) values (1, 300);
insert into comptes (numclient, solde) values (2, 200);
insert into comptes (numclient, solde) values (3, 200);

insert into resa(prix) values (30);
insert into resa(prix) values (30);
insert into resa(prix) values (20);
insert into resa(prix) values (20);


--
-- CREATION DE LA BASE DES NOTES
--

DROP TABLE IF EXISTS note;
DROP TABLE IF EXISTS enseigne;
DROP TABLE IF EXISTS etudiant;

CREATE TABLE etudiant (
   numEtudiant INT PRIMARY KEY,
   nom VARCHAR(40) NOT NULL,
   prenom VARCHAR(40) NOT NULL,
   login VARCHAR(20) NOT NULL ,
   UNIQUE (nom, prenom),
   UNIQUE (login)
);

CREATE TABLE enseigne (
   login VARCHAR(20),
   codeMatiere VARCHAR(20),
   PRIMARY KEY (login, codeMatiere)
);

CREATE TABLE note (
   codeMatiere VARCHAR(20),
   numEtudiant INT REFERENCES etudiant,
   note INT CHECK ((note >=0) AND (note <=20)),
   PRIMARY KEY (codeMatiere, numEtudiant)
);

INSERT INTO etudiant(numEtudiant, nom, prenom, login)
VALUES
  (11111, 'Ball', 'Lucille', 'BALL'),
  (22222, 'Arnaz', 'Desi', 'ARNAZ'),
  (33333, 'Marx', 'Groucho', 'MARX'),
  (44444, 'Abbott', '', 'ABBOTT'),
  (55555, 'Costello', '', 'COSTELLO')
;

INSERT INTO enseigne (login, codeMatiere)
VALUES
  ('Zielonka', 'BDA'),
  ('Laroussinie', 'Algo')
;

INSERT INTO note (codeMatiere, numEtudiant )
VALUES
  ('BDA', 11111),
  ('BDA', 22222),
  ('BDA', 33333),
  ('Algo', 11111),
  ('Algo', 33333),
  ('Algo', 44444),
  ('Algo', 55555)
;
