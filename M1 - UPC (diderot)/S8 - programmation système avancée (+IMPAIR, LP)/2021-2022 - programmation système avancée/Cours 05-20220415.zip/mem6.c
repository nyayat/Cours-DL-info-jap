#include <sys/mman.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include "panic.h"
#include "prefix_slash.h"
#include "data.h"
int main(int argc, char **argv){
  if(argc != 3){
    fprintf(stderr, "usage : basename(arv[0]) shared_memory_object  message\n");
    return 1;
  }
  //ajouter / au debut du nom si necessaire
  char * nom=prefix_slash(argv[1]);  
  int fd;
  printf("objet = \"%s\"\n", nom);
  if( ( fd = shm_open( nom, O_RDWR|O_CREAT , S_IRUSR|S_IWUSR) ) == -1)
    PANIC_EXIT("shm_open");
  printf("fd=%d\n", fd);
  
  size_t str_len = strlen(argv[2]) ;
  size_t tot_len = str_len + sizeof(struct data);
  
  if( ftruncate( fd, tot_len ) == -1)
    PANIC_EXIT("ftruncate");

  void * adr = mmap(NULL, tot_len, PROT_READ|PROT_WRITE, MAP_SHARED, fd, 0) ;
  if(adr == MAP_FAILED)
    PANIC_EXIT("mmap");
  close(fd);
  struct data *msg = adr;
  msg->len_mess = str_len;
  memcpy(&(msg->mess), argv[2], str_len);
  
  if( msync( adr, tot_len, MS_SYNC) == -1)
    PANIC_EXIT("msync");

  if( munmap(adr, tot_len) == -1)
    PANIC_EXIT("munmap");

  return 0;
}

