#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <string.h>
#include <sys/stat.h>
#include <libgen.h>
#include <stdlib.h>
#include "panic.h"
/*  cp avec mmap version simple */

int main(int argc, char **argv) {
  if( argc != 3){
    fprintf(stderr,"usage : %s source destination\n", basename(argv[0]));
    exit(2);
  }

  int src = open( argv[1], O_RDONLY);
  if( src < 0 ){
    PANIC_EXIT(3);
  }

  int dest = open( argv[2], O_RDWR|O_CREAT|O_TRUNC, 0666);
  //int dest = open( argv[2], O_WRONLY|O_CREAT|O_TRUNC, 0666);
  if( dest < 0 ){
    PANIC_EXIT(3);
  }
  
  struct stat bufStat;  
  if( fstat( src, &bufStat ) < 0 ){
    PANIC_EXIT(4);
  }
  size_t len = bufStat.st_size;
  if( ftruncate( dest, len ) < 0 ){
    PANIC_EXIT(5);
  }
  //projecion privee de fichier source
  void *srcmem = mmap(0, len, PROT_READ, MAP_PRIVATE, src, 0);
  if (srcmem == MAP_FAILED){
    PANIC_EXIT(6);
  }
  //projection  publique de fichier dest
  void *destmem = mmap(0, len,  PROT_WRITE, MAP_SHARED, dest, 0);
  if(destmem == MAP_FAILED ){
    PANIC_EXIT(7);
  }
  close(src); close(dest);
  //copier len octets de srcmem vers srcdest
  memcpy(destmem, srcmem, len);
  msync(destmem, len, MS_SYNC); //synchroniser avec le fichier out,pas vraiment necessaire
  
  munmap(srcmem, len);
  munmap(destmem, len);

  exit(0);
}
    
  
