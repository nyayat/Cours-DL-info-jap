#include <stdlib.h>
#include <string.h>

#define LEN 5

char **split(char *s){
  char **result = (char **)calloc(LEN, sizeof(char *));
  int len = LEN, n = 0;
  char *token;
  const char delim[3] = " \t";

  if(s==NULL || strlen(s)==0){ // chaine vide
    result = realloc(result, 1);
    return result;
  }

  token = strtok(s, delim);
  while(token){
    if(n==len){
      len *= 2;
      result = realloc(result, len*sizeof(char *));
    }
    result[n++] = token;
    token = strtok(NULL, delim);
  }
  if(n==len){
    len++;
    result = realloc(result, len*sizeof(char *));
  }  
  result[n++] = NULL;
  if(n<len)
    result = realloc(result, n*sizeof(char *));

  return result;
}


int main(int argc, char **argv){
  char **r;
  if (argc>1){
    r = split(argv[1]);
  }
}
