public class Roturier extends Personne implements Cloneable {

    public Roturier(String nom, int argent, int pdv) {
        super(nom, argent, pdv);
    }

    @Override
    public Roturier clone() throws CloneNotSupportedException {
        return (Roturier) super.clone();
    }

    @Override
    public boolean equals(Object obj) {
        if (this.getClass() == obj.getClass()) {
            Roturier r = (Roturier) obj;
            if (r.nom == this.nom
                && r.argent == this.argent
                && r.pdv == this.pdv)
            {
                return true;
            }
        }
        return false;
    }
}
