import java.util.LinkedList;

public class Test {
    public static void out(Object o) {
        System.out.println(o);
    }

    public static void main(String[] args)
    throws CloneNotSupportedException {
        LinkedList<Roturier> rs1 = new LinkedList<Roturier>();
        LinkedList<Roturier> rs2 = new LinkedList<Roturier>();
        Roturier robert = new Roturier("Robert", 4, 100);
        Paysan roberto = new Paysan("Robert", 4, 100);
        rs1.add(robert);
        rs1.add(roberto);
        rs2.add(roberto);
        rs2.add(robert);

        // Exercice 3
        /**
         * Erreur attendu : clone() has protected access in Object
         */
        // Personne foo = new Personne ("Moi", 10000, 99) ;
        // Personne bar = foo.clone();

        Roturier fanta = new Fantassin("Fanta4", 4, 100);
        Roturier fanta2 = fanta.clone();
        System.out.println(fanta.getClass());
        System.out.println(fanta2.getClass());

        // Exercice 3 et 4
        Village v1 = new Village(rs1);
        Village v2 = new Village(rs2);
        Village vClone = v1.clone();
        System.out.println(v1.equals(vClone));
        System.out.println(v1.equals(v2));
    }
}
