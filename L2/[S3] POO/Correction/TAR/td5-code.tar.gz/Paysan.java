public class Paysan extends Roturier {

    public Paysan(String nom, int argent, int pdv) {
        super(nom, argent, pdv);
    }
}
