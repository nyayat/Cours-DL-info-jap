import java.util.LinkedList;

public class Village implements Cloneable  {
    LinkedList<Roturier> habitants;

    public Village(LinkedList<Roturier> h) {
        habitants = h;
    }

    public int volArgent() {
        int somme = 0;
        for (int i = 0; i < habitants.size(); i++) {
            Personne h = habitants.get(i);
            // chaque villageois se fait voler la moitié de son argent
            int vol = h.getArgent() / 2;
            if (h.perte(vol)) {
                somme += vol;
            }
        }
        return somme;
    }

    @Override
    public Village clone() throws CloneNotSupportedException {
        LinkedList<Roturier> habitantsCopy = new LinkedList<Roturier>();

        for(Roturier r : habitants) {
            habitantsCopy.add(r.clone());
        }

        Village clone = (Village) super.clone();
        clone.habitants = habitantsCopy;

        return clone;
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Village)) {
            return false;
        }

        Village v = (Village) o;
        int s = this.habitants.size();

        if (v.habitants.size() != s) {
            return false;
        }
        
        for (int i = 0; i < s; i++) {
            Roturier r1 = this.habitants.get(i);
            Roturier r2 = v.habitants.get(i);
            if (! r1.equals(r2)) {
                return false;
            }
        }
        return true;
    }
}
