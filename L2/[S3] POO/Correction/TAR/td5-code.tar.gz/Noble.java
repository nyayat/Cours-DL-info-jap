import java.util.LinkedList;

public class Noble extends Personne {
    public Noble(String nom, int argent, int pdv) {
        super(nom, argent, pdv);
    }
}
