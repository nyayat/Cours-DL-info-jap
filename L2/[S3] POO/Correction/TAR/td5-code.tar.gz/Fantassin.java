public class Fantassin extends Roturier {
    int degats = 15;

    public Fantassin(String n, int a, int pdv) {
        super(n, a, pdv);
    }

    public void attaque(Personne p) {
        if (p instanceof Chevalier) {
            ((Chevalier) p).capturedBy(this);
        } else {
            p.blessure(degats);
        }
    }
}
