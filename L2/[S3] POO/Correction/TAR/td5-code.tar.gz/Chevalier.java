public class Chevalier extends Noble {
    private static final int prixLiberté = 50;
    private boolean estLibre = true;
    private Personne geolier = null;

    public Chevalier(String n, int a, int pdv) {
        super(n, a, pdv);
    }

    public void attaque(Personne p) {
        if (p instanceof Chevalier && this.estLibre) {
            ((Chevalier) p).capturedBy(this);
        }
    }

    public void capturedBy(Personne geolier) {
        this.geolier = geolier;
        this.estLibre = false;
    }

    public boolean acheteLiberte() {
        if (this.estLibre) {
            return false;
        }
        if (this.perte(prixLiberté)) {
            this.geolier.gain(prixLiberté);
            this.estLibre = true;
            this.geolier = null;
            return true;
        }
        return false;
    }
}
