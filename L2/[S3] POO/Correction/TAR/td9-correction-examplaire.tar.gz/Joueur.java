import java.util.LinkedList;
import java.util.Scanner;

public class Joueur {
  int numero;
  Grille grille; // grille de bateaux
  // Il faudrait egalement ajouter une grille d'attaque contenant des elements de type Pion
  private LinkedList<Bateau> flotte;

  /*
     Chaque joueur possède sa propre grille
     et sa propre flotte.
  */
  public Joueur(int n) {
    numero = n;
    this.grille = new Grille();
    this.flotte = new LinkedList<>();
  }

  /*
     Tir retourne vrai en cas de succès
  */
  public boolean tir(int x, int y, Joueur adversaire) {
    if (adversaire.grille.tir(x, y)) {
      System.out.println("Touché !");
      return true;
    }
    System.out.println("Raté !");
    return false;
  }

  public void tour(Joueur adversaire) {
    System.out.println("Tour du joueur " + numero + " : ");
    Scanner s = new Scanner(System.in);
    int x = s.nextInt();
    int y = s.nextInt();
    this.tir(x, y, adversaire);
  }

  public boolean perdu() {
    /*
       On a perdu si tous les bateaux ont coulé
    */
    for (int i = 0; i < flotte.size(); i++) {
      if (!flotte.get(i).coule()) return false;
    }
    return true;
  }

  /*
     On demande au joueur de choisir les emplacements
     de ses bateaux. Sous réserve que ceux-ci
     soient valides.
  */
  public void preparation() {
    int x, y;
    boolean z;
    Scanner s = new Scanner(System.in);

    System.out.println("Player " + numero + ", placez votre flotte ! ");

    for (int i = 2; i < 5; i++) { // un while serait plus adapté en cas de mauvaise position
      System.out.println("Ou placer un bateau de taille " + i + " ?");
      x = s.nextInt();
      y = s.nextInt();
      z = s.nextBoolean();

      BateauDeSurface t = new BateauDeSurface(i);
      if (this.grille.placeBateauDeSurface(t, x, y, z)) {
        this.flotte.add(t);
      } else {
        System.out.println("Position invalide !");
        i--;
      }
    }

    boolean invalide = true;
    while (invalide) {
      System.out.println("Ou placer le porte-avion ?");
      x = s.nextInt();
      y = s.nextInt();
      z = s.nextBoolean();

      PorteAvions t = new PorteAvions();
      if (this.grille.placeBateauDeSurface(t, x, y, z)) {
        this.flotte.add(t);
        invalide = false;
      } else {
        System.out.println("Position invalide !");
      }
    }

    invalide = true;
    while (invalide) {
      System.out.println("Ou placer le sous-marin ?");
      x = s.nextInt();
      y = s.nextInt();
      z = s.nextBoolean();

      Sousmarin t = new Sousmarin();
      if (this.grille.placeSousmarin(t, x, y, z)) {
        this.flotte.add(t);
        invalide = false;
      } else {
        System.out.println("Position invalide !");
      }
    }
  }
}
