public class Grille {
  public static final int dim = 10;
  private Case[][] coordonnees = new Case[dim][dim];

  public Grille() {
    for (int i = 0; i < dim; i++) {
      for (int j = 0; j < dim; j++) {
        coordonnees[i][j] = new Case(i, j);
      }
    }
  }

  public Case get(int i, int j) {
    /* Get is readonly */
    return new Case(coordonnees[i][j]);
  }

  public boolean caseLibre(int i, int j) {
    return get(i, j).estLibre();
  }

  public boolean tir(int i, int j) {
    return coordonnees[i][j].hit();
  }

  public boolean positionValide(int taille, int x, int y, boolean vertical) {
    /* Si vertical, la composante
    horizontale est nulle.
     Et inversement */
    int vert = (vertical) ? 1 : 0;

    /* Toutes les cases sont elles valides ? */
    for (int i = 0; i < taille; i++) {
      int xi = x + (1 - vert) * i;
      int yi = y + vert * i;

      /* Dépasse t'on le tableau ? */
      if (xi < 0 || xi >= dim || yi < 0 || yi >= dim) return false;

      /* La case est-elle libre ? */
      if (!this.caseLibre(xi, yi)) return false;
    }

    return true;
  }

  public boolean pasdAdjacence(int taille, int x, int y, boolean vertical) {
    if (vertical) {
      for (int i = 0; (i < taille); i++) {
        if (x - 1 >= 0 && this.get(x - 1, y + i).contientBateauDeSurface()) return false;
        if (x + 1 < dim && this.get(x + 1, y + i).contientBateauDeSurface()) return false;
      }
    } else {
      for (int i = 0; (i < taille); i++) {
        if (y - 1 >= 0 && this.get(x + i, y - 1).contientBateauDeSurface()) return false;

        if (y + 1 < dim && this.get(x + i, y + 1).contientBateauDeSurface()) return false;
      }
    }
    return true;
  }

  private void placeBateau(Bateau b, int x, int y, boolean v) {
    int vert = (v) ? 1 : 0;

    /* On place le bateau */
    for (int i = 0; i < b.getTaille(); i++) {
      int xi = x + (1 - vert) * i;
      int yi = y + vert * i;

      this.coordonnees[xi][yi].setBateau(b, i);
    }
  }

  /*
     Renvoie vrai en cas de succès du placement
  */
  public boolean placeBateauDeSurface(BateauDeSurface b, int x, int y, boolean v) {
    int taille = b.getTaille();

    /* On vérifie que la position est valide */
    if (!positionValide(taille, x, y, v)) return false;

    if (!pasdAdjacence(taille, x, y, v)) return false;

    placeBateau(b, x, y, v);

    return true;
  }

  /*
     Renvoie vrai en cas de succès du placement
  */
  public boolean placeSousmarin(Sousmarin b, int x, int y, boolean v) {
    int taille = b.getTaille();

    /* On vérifie que la position est valide */
    if (!positionValide(taille, x, y, v)) return false;

    placeBateau(b, x, y, v);

    return true;
  }
}
