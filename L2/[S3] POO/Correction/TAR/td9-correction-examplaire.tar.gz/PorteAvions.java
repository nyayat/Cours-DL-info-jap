public class PorteAvions extends BateauDeSurface {
  public static final int taillePorteAvion = 5;

  public PorteAvions() {
    super(taillePorteAvion);
  }
}
