public class Case {
  /* Final car une case ne bouge pas */
  private final int x;
  private final int y;

  /* On conserve le lien vers le bateau
     et le numéro de sa section.
  */
  private Bateau element;
  private int section;

  public Case(int x, int y) {
    this.x = x;
    this.y = y;
  }

  public Case(Case c) {
    this.x = c.x;
    this.y = c.y;
    this.element = c.element;
    this.section = c.section;
  }

  public void setBateau(Bateau b, int s) {
    element = b;
    section = s;
  }

  public boolean hit() {
    if (element != null) {
      /*
         On indique au bateau qu'une
         de ses sections a été touchée.
      */
      element.sectionTouchee(section);
      return true;
    }
    return false;
  }

  public int getY() {
    return y;
  }

  public int getX() {
    return x;
  }

  public boolean estLibre() {
    return this.element == null;
  }

  public boolean contientBateauDeSurface() {
    return this.element instanceof BateauDeSurface;
  }
}
