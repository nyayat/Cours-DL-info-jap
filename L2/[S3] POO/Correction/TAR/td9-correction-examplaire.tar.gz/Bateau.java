public abstract class Bateau {
  private int dim;
  protected boolean[] touche;

  /*
     Un bateau n'a pas conscience de sa position
     seule la grille sait ou sont les bateaux.
  */

  public Bateau(int dim) {
    this.dim = dim;
    this.touche = new boolean[dim];

    for (int i = 0; i < dim; i++) this.touche[i] = false;
  }

  public int getTaille() {
    return dim;
  }

  public boolean coule() {
    for (int i = 0; i < dim; i++) {
      if (!this.touche[i]) return false;
    }
    return true;
  }

  /*
   * Retourne vrai si le bateau est coulé
   * après avoir été touché, faux sinon.
   */
  public boolean sectionTouchee(int section) {
    this.touche[section] = true;
    return this.coule();
  }
}
