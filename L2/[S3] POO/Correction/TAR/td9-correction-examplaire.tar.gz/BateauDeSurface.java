public class BateauDeSurface extends Bateau {
  public BateauDeSurface(int dim) {
    super(dim);
  }
}
