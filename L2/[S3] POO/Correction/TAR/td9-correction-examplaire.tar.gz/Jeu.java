/** Correction retravaillée par Ulysse Gérard pour l'année 2018 / 2019 */
public class Jeu {
  Joueur player1;
  Joueur player2;

  public Jeu() {
    this.player1 = new Joueur(1);
    this.player2 = new Joueur(2);
  }

  public boolean tour() {
    this.player1.tour(this.player2);
    if (this.player2.perdu()) return false;
    this.player2.tour(this.player1);
    if (this.player1.perdu()) return false;
    return true;
  }

  public void play() {
    this.player1.preparation();
    this.player2.preparation();

    while (this.tour()) {}
    ;
  }

  public static void main(String[] args) {
    Jeu j = new Jeu();

    j.play();
  }
}
