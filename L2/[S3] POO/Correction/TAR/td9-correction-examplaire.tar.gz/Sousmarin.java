public class Sousmarin extends Bateau {
  public static final int tailleSousmarin = 3;

  public Sousmarin() {
    super(3);
  }
}
