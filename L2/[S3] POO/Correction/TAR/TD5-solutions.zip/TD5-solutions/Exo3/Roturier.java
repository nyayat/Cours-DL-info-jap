package correction;

public class Roturier extends Personne implements Cloneable {

    public Roturier(String nom, int argent, int pdv) {
        super(nom, argent, pdv);
    }

    // Exo 3.1
    @Override
    public Roturier clone() throws CloneNotSupportedException {
        return (Roturier) super.clone();
    }
}
