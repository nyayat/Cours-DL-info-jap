package correction;

public class Roturier extends Personne {

    public Roturier(String nom, int argent, int pdv) {
        super(nom, argent, pdv);
    }
}
