package correction;

public class Chevalier extends Noble {
    // Exo 1.2(b)
    private Personne geolier;
    // Exo 1.3
    private static final int prixLiberté = 50;

    public Chevalier(String n, int a, int pdv) {
        super(n, a, pdv);
    }

    // Exo 1.2(b)
    public void attaque(Personne p) {
        if(p instanceof Chevalier) {
            ((Chevalier) p).geolier = this;
        }
    }

    // Exo 1.2(c)
    public void capture(Fantassin x) {
        this.geolier = x;
    }

    // Exo 1.3
    public boolean acheteLiberte() {
        if(this.perte(prixLiberté)) {
            geolier.gain(prixLiberté);
            this.geolier = null;
            return true;
        }
        return false;
    }
}
