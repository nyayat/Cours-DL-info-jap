package correction;

import java.util.LinkedList;

public class Village {
    LinkedList<Roturier> habitants;

    public Village(LinkedList<Roturier> h) {
        habitants = h;
    }

    public int volArgent() {
        int somme = 0;
        for (int i = 0; i < habitants.size(); i++) {
            Personne h = habitants.get(i);
            int vol = h.getArgent() / 2;
            if(h.perte(vol))
                somme += vol;
        }
        return somme;
    }
}
