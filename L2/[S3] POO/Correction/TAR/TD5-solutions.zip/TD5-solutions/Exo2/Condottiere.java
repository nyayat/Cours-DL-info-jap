package correction;

import java.util.LinkedList;

public class Condottiere extends Personne {
    LinkedList<Archer> archers = new LinkedList<Archer>();
    LinkedList<Fantassin> fantassins = new LinkedList<Fantassin>();

    public Condottiere(String n, int a, int pdv) {
        super(n, a, pdv);

        archers.add(new Archer("Tom", 5, 100));
        fantassins.add(new Fantassin("Tom2", 8, 100));
    }

    public void attaque(Village v) {
        int vol = v.volArgent();
        int m = vol / 2;
        int nCie = archers.size() + fantassins.size();
        int reste = m / nCie;

        this.gain(m);

        for (int i = 0; i < archers.size() ; i++) {
            archers.get(i).gain(reste);
        }

        for (int i = 0; i < fantassins.size() ; i++) {
            fantassins.get(i).gain(reste);
        }
    }
}
