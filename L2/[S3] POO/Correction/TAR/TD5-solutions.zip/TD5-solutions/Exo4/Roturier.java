package correction;

public class Roturier extends Personne implements Cloneable {

    public Roturier(String nom, int argent, int pdv) {
        super(nom, argent, pdv);
    }

    // Exo 3.1
    @Override
    public Roturier clone() throws CloneNotSupportedException {
        return (Roturier) super.clone();
    }

    // Exo 4.1
    @Override
    public boolean equals(Object obj) {
        if(this.getClass() == obj.getClass()) {
            Roturier r = (Roturier) obj;
            if(r.nom == this.nom
                && r.pdv == this.pdv)
                return true;
        }
        return false;
    }
}
