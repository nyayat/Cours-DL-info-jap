interface Accumulator<S> {

  public boolean isOver();

  /**
   * acumule l'element courant (en le combinant
   * avec un element externe e, et se deplace sur
   * le prochain element du parcours
   **/
  public void accumulate(S e);

  /**
   * recupere la valeur de l'accumulateur
   **/
  public S read();

}
