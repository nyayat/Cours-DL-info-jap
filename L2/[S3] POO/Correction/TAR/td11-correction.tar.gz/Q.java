import java.util.Arrays;

public class Q {
  // produit scalaire entre la ligne i et le tableau b
  public static double dotProduct(Matrix<Double> m, int i, double[] b) {
    if (i < 0 || i >= m.nRows() || b.length != m.nCols()) throw new IllegalArgumentException();
    AccFunction<Double, Double> dot_product = (Double x, Double y, Double z) -> x + (y * z);
    Accumulator<Double> v = m.<Double>rowScanner(i, dot_product, 0.0);
    for (int j = 0; j < b.length; j++) {
      v.accumulate(b[j]);
    }
    return v.read();
  }

  // checks all values of j-column are bigger or equal to b
  public static boolean lowerBound(Matrix<Double> m, int j, int b) {
    // La fonction n'utilise pas l'élément extèrne y
    AccFunction<Boolean, Double> lower_bound = (Boolean x, Boolean y, Double z) -> (x && (z >= b));
    Accumulator<Boolean> v = m.<Boolean>colScanner(j, lower_bound, true);
    while (!v.isOver()) {
      // true est la valeur pour l'élément extèrne y qui n'est pas utilisé,
      // donc on pourrait aussi utiliser false.
      v.accumulate(true);
    }
    return v.read();
  }

  /**
   * Main method for command-line invocation.
   *
   * @param args the argument String array
   */
  public static void main(String args[]) throws InvalidContentException {
    Double[][] t = {{2.0, 3.0, 4.0}, {5.0, 6.0, 7.0}};
    double[] b = {1.0, 2.0, 2.0};
    Matrix<Double> m = new Matrix<Double>(t);
    System.out.println(dotProduct(m, 1, b));
    System.out.println(lowerBound(m, 1, 4));

    Double[][] t1 = {{1.0, 0.0, 4.0}, {0.0, 6.0, 0.0}};
    FunctionalMatrix<Double> m1 = new FunctionalMatrix<Double>(t1);
    Double[] fun = new Double[3];
    m1.content(fun);
    System.out.println(Arrays.toString(fun));

    // test of code in the text :
    Accumulator<Integer> a = m.<Integer>colScanner(0, (Integer x, Integer y, Double z) -> x + y, 0);
    while (!a.isOver()) {
      a.accumulate(2);
    }
    Integer i = a.read();
  }
}
