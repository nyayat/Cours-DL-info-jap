class Matrix<T> {
  private T[][] data;

  protected boolean checkContent(T[][] t) {
    return true;
  }

  public Matrix(T[][] m) throws InvalidContentException {
    if (m.length == 0 || m[0].length == 0) {
      throw new IllegalArgumentException();
    }
    if (!checkContent(m)) {
      throw new InvalidContentException();
    }
    // Il faudrait indiquer dans le manuel de cette classe que
    // le constructeur ne clone pas le tableau donné en paramètre.
    data = m;
  }

  public int nRows() {
    return data.length;
  }

  public int nCols() {
    return data[0].length;
  }

  private class MatrixScanner<S> implements Accumulator<S> {
    private int i; // la position (i,j) sous le curseur
    private int j; //
    private int di = 0; // le deplacement unitaire sur les lignes
    private int dj = 0; // le deplacement unitaire sur les colonnes
    private S acc; // la valeur accumulée
    private AccFunction<S, T> f; // la fonction d'accumulation

    // vérifie que (i,j) est l'indice d'une case du tableau parcouru
    private boolean checkIndex(int i, int j) {
      return !(i < 0 || i >= nRows() || j < 0 || j >= nCols());
    }

    MatrixScanner(int i, int j, int di, int dj, AccFunction<S, T> f, S acc) {
      if (!checkIndex(i, j)) {
        throw new IllegalArgumentException();
      }
      this.i = i;
      this.j = j;
      this.di = di;
      this.dj = dj;
      this.f = f;
      this.acc = acc;
    }

    public boolean isOver() {
      return (i >= nRows() || j >= nCols());
    }

    /**
     * accumule la prochaine valeur à lire
     * apres l'avoir combinée avec e, et
     * ensuite  déplace le curseurs de (di,dj)
     **/
    public void accumulate(S e) {
      if (checkIndex(i, j)) {
        acc = f.apply(acc, e, data[i][j]);
        i += di;
        j += dj;
      }
    }

    public S read() {
      return acc;
    }
  }

  public <S> Accumulator<S> rowScanner(int i, AccFunction<S, T> f, S initAcc) {
    return this.new MatrixScanner<S>(i, 0, 0, 1, f, initAcc);
  }

  public <S> Accumulator<S> colScanner(int j, AccFunction<S, T> f, S initAcc) {
    return this.new MatrixScanner<S>(0, j, 1, 0, f, initAcc);
  }
}

class FunctionalMatrix<T extends Number> extends Matrix<T> {
  private boolean empty(T v) {
    return v.intValue() == 0;
  }

  protected boolean checkContent(T[][] t) {
    for (int j = 0; j < t[0].length; j++) {
      int not_empty = 0;
      for (int i = 0; i < t.length; i++) {
        // Pour comparer avec l'élément zéro de T, on utilise empty()
        if (!empty(t[i][j])) {
          not_empty++;
        }
      }
      if (not_empty > 1) {
        return false;
      }
    }
    return true;
  }

  public FunctionalMatrix(T[][] m) throws InvalidContentException {
    super(m);
  }
  // assumption : @arg t contains all empty values at the beginning, but does not relly matter
  public void content(T[] t) {
    if (t.length != nCols()) {
      throw new IllegalArgumentException();
    }
    for (int j = 0; j < nCols(); j++) {
      // Le dernier élément est t[0]. Intuitivement, on veut y mettre le
      // zéro du type T. Comme on suppose que t contiens que des zéros,
      // c'est bon.
      Accumulator<T> v = colScanner(j, (T x, T y, T z) -> empty(z) ? x : z, t[0]);
      while (!v.isOver()) {
        v.accumulate(t[0]);
      }
      t[j] = v.read();
    }
  }
}
