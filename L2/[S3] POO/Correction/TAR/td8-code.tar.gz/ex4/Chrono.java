import java.awt.event.*;
import java.time.LocalTime;
import javax.swing.*;

public class Chrono {
  public static void main(String[] args) {
    new JFrame().setVisible(true);
    // necessaire pour des raisons techniques :
    // demarrer l'event dispatcher,
    // le meme qui s'occupera de gerer les evenement de timer

    int delay = 1000; // milliseconds

    // Exo 3.1
    ActionListener afficheHeure =
        new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            System.out.println(LocalTime.now());
          }
        };
    Timer t1 = new Timer(delay, afficheHeure);

    // Exo 3.2 : avec une expression Lambda
    /*
    Timer t1 = new Timer(delay, (evt) -> System.out.println(LocalTime.now()));
    t1.start();
    */

    // Exo 3.3
    // Ce timer doit avoir un état interne
    // en plus d'incrementer actionPerformed.
    // Nous avons donc besoin d'une classe locale,
    // une expression lambda ne suffit pas.
    /*
    ActionListener compteMoutons = new ActionListener() {
        private int count = 0;
        public void actionPerformed(ActionEvent evt) {
          System.out.println(++count);
        }
    };
    Timer t2 = new Timer(2000, compteMoutons);
    t2.start();
    */
  }
}
