public interface BoiteAEntiers {
  int lire(int index);

  void ajouter(int valeur);

  void vider();

  int nombreDElements();

  default void inserer(int index, int valeur) {
    throw new UnsupportedOperationException("La méthode inserer n'est pas définie.");
  }

  default int retirer(int index) {
    throw new UnsupportedOperationException("La méthode retirer n'est pas définie.");
  }

  // On donne une implementation par défaut pour ne pas devoir modifier les classes qui
  // implémentent l'interface.
  default void ajoutRisque(Object o) {
    if (!(o instanceof Integer)) {
      throw new IllegalArgumentException();
    }
    ajouter((Integer) o);
  }
}
