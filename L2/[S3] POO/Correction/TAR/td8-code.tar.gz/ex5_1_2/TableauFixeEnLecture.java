public class TableauFixeEnLecture implements BoiteAEntiers {
  // on en peux pas modifier le tableau, on peut l'implementer par un int[]
  private int[] t;

  public static class EcritureInterditeException extends LectureEcritureException {}

  public TableauFixeEnLecture(int[] t) {
    int[] copy = new int[t.length];

    for (int i = 0; i < t.length; i++) {
      copy[i] = t[i];
    }

    this.t = copy;
  }

  // on redefinit les methodes en lecture

  @Override
  public int lire(int index) {
    return t[index];
  }

  @Override
  public int nombreDElements() {
    return t.length;
  }

  // On ne redefinit pas insere et retirer ce qui leur laissera l'implementation par
  // qui leve UnsupportedOperationException.

  // On redefinit les methodes abstraites d'écriture, pour qu'elle levent
  // EcritureInterditeException.
  @Override
  public void ajouter(int valeur) {
    throw new EcritureInterditeException();
  }

  @Override
  public void vider() {
    throw new EcritureInterditeException();
  }
}
