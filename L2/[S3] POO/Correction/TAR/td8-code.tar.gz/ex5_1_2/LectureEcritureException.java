public class LectureEcritureException extends UnsupportedOperationException // une RuntimeException
{}
