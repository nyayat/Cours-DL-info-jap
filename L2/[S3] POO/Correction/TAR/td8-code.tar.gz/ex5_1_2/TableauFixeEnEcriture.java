import java.util.LinkedList;

public class TableauFixeEnEcriture implements BoiteAEntiers {
  // on doit pouvoir modifier ce tableau, on adopte une implementation par liste
  private LinkedList<Integer> t = new LinkedList<>();

  public static class LectureException extends LectureEcritureException {}

  // on redefinit les methodes de lecture pour qu'elle soulevent LectureException
  @Override
  public int lire(int index) {
    throw new LectureException();
  }

  @Override
  public int nombreDElements() {
    throw new LectureException();
  }

  // on implemente les methodes d'écriture
  // (sauf retirer qui continue de soulever UnsupportedOperationException)
  @Override
  public void ajouter(int valeur) {
    t.add(valeur);
  }

  @Override
  public void inserer(int index, int valeur) {
    t.add(index, valeur);
  }

  /*    @Override
  public int retirer(int index) {
      return t.remove(index);
  }*/

  @Override
  public void vider() {
    t = new LinkedList<>();
  }
}
