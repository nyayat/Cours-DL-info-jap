import java.util.Random;

public class Universite {
    private int nbEtu;  // nombre d’étudiants inscrits à l’université
    private int capALL; // capacité en arts, lettres, langues
    private int capSHS; // capacité en sciences humaines et sociales
    private int capSTS; // capacité en sciences, technologies et santé

    public static class TropPeuDCapaciteException extends RuntimeException {}

    public static class DirectiveMinisterielleException extends Exception {
        public DirectiveMinisterielleException(String m) {
            super(m);
        }
    }

    public Universite(int nbe, int ca, int csh, int cst) {
        if (nbe < 0 || ca < 0 || csh < 0 || cst < 0 || nbe > (ca + csh + cst)) {
            throw new IllegalArgumentException("Mauvais arguments pour constructeur d'Université");
        }
        nbEtu = nbe;
        capALL = ca;
        capSHS= csh;
        capSTS = cst;
    }

    public void restructuration(int ca, int csh, int cst) throws DirectiveMinisterielleException {
        if (nbEtu > ca + csh + cst)
            throw new TropPeuDCapaciteException();
        else if (ca > csh + cst)
            throw new DirectiveMinisterielleException("Trop de ALL");
        else if (csh > ca + cst)
            throw new DirectiveMinisterielleException("Trop de SHS");
        else if (cst > ca + csh)
            throw new DirectiveMinisterielleException("Trop de STS");
        capALL = ca;
        capSHS = csh;
        capSTS = cst;
    }

    public void restrictionBudgetaire() throws DirectiveMinisterielleException {
        Random sourceAlea = new Random();
        int nCapALL = sourceAlea.nextInt((int) (0.9 * capALL));
        int nCapSHS = sourceAlea.nextInt((int) (0.9 * capSHS));
        int nCapSTS = sourceAlea.nextInt((int) (0.9 * capSTS));

        try {
            this.restructuration(nCapALL, nCapSHS, nCapSTS);
        } catch (TropPeuDCapaciteException e) {
            reduction(10);
        } catch (DirectiveMinisterielleException e) {
            nCapALL = sourceAlea.nextInt((int) (0.9 * capALL));
            nCapSHS = sourceAlea.nextInt((int) (0.9 * capSHS));
            nCapSTS = sourceAlea.nextInt((int) (0.9 * capSTS));

        } finally {
            if (capALL != nCapALL || capSHS != nCapSHS || capSTS != nCapSTS) {
            	this.restructuration(nCapALL, nCapSHS, nCapSTS);
            }
        }
    }

    public void reduction(int nb) {
        nbEtu -= nb;
    }
}
