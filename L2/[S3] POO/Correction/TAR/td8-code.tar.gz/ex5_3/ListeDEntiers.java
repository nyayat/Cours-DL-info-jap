import java.util.LinkedList;

public class ListeDEntiers implements BoiteAEntiers {
  // on doit pouvoir modifier ce tableau, on adopte une implementation par liste
  private LinkedList<Integer> t = new LinkedList<>();

  // on implemente toute les methodes
  @Override
  public int lire(int index) {
    return t.get(index);
  }

  @Override
  public int nombreDElements() {
    return t.size();
  }

  @Override
  public void ajouter(int valeur) {
    t.add(valeur);
  }

  @Override
  public void inserer(int index, int valeur) {
    t.add(index, valeur);
  }

  @Override
  public int retirer(int index) {
    return t.remove(index);
  }

  @Override
  public void vider() {
    t = new LinkedList<>();
  }
}
