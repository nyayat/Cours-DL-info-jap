public class Universite {
    private int nbEtu;  // nombre d’étudiants inscrits à l’université
    private int capALL; // capacité en arts, lettres, langues
    private int capSHS; // capacité en sciences humaines et sociales
    private int capSTS; // capacité en sciences, technologies et santé

    public Universite(int nbe, int ca, int csh, int cst) {
        if (nbe < 0 || ca < 0 || csh < 0 || cst < 0 || nbe > (ca + csh + cst)) {
            throw new IllegalArgumentException("Mauvais arguments pour constructeur d'Université");
        }
        nbEtu = nbe;
        capALL = ca;
        capSHS= csh;
        capSTS = cst;
    }
}
