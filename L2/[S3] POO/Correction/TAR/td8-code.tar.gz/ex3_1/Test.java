public class Test {
    public static void main(String[] args) {
        Universite u = new Universite(3, 4, 4, 4);
        Universite u2 = new Universite(200, 4, 4, 4);
    }
}
