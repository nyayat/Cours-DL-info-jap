class CallF extends Exception {}
class CallG extends Exception {}
class CallH extends CallF{}

public class Test {
  public static void f() throws CallF, CallG, CallH {throw new CallF();}
  public static void g() throws CallF, CallG, CallH {throw new CallG();}
  public static void h() throws CallF, CallG, CallH {throw new CallH();}
  public static void skip() throws CallF, CallG, CallH {}

  public static void main(String[] args) throws CallF, CallG {
    try { f(); }
    finally { System.out.println("Finally"); g(); }
  }
}
