class C {
    public C() { System.out.println("Hello"); }
}

