class D extends C {
    private int x;
    public D(int x) { this.x = x; }
}
