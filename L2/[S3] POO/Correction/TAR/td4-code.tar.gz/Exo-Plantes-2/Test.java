public class Test {

    public static void main(String args[]) {
        Plante[] serre = new Plante[5];
	serre[0] = new Plante();
	serre[1] = new PlanteFleurie();
	serre[2] = new Plante();
	serre[3] = new PlanteFleurie();
	serre[4] = new Plante();
	System.out.println ( Plante.Etat() );
	System.out.println ( PlanteFleurie.Etat() );
	for(int i=0; i<5; i++) {
            serre[i].arrosage();
            System.out.println(serre[i]);
    	}
        System.out.println(Plante.Etat());
        System.out.println(PlanteFleurie.Etat());
    }
}
