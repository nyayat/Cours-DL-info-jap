/**
 *
 * @author berenice
 */
public class Plante {
    private static int nbPlanteSoif;
    private boolean arrosee=false;

    public Plante() {
        nbPlanteSoif++;
    }

    public String toString() {
        if (this.arrosee){
            return "J'ai été arrosée";
        }
        else {
            return "J'ai soif";
        }
    }

    public static String Etat() {
        return "Il y a " + nbPlanteSoif + " plantes qui ont soif.";
    }

      // derniere question
    public void arrosage() {
        if (! arrosee) {
       	 	arrosee = true;
        	nbPlanteSoif--;
        }
    }

}
