public class MaisonLouable extends Maison {
    // Exo 5.2
    private Personne locataire;
    public boolean louee () {
	return locataire != null;
    }
    
    MaisonLouable(String adresse, int surfaceH, int surfaceJ, int nbPieces, Personne prop) {
    	super(adresse, surfaceH, surfaceJ, nbPieces, prop);
    }
    
    public void louerA(Personne p) {
    	locataire = p;
    	locataire.louer(this);
    }

    public void payerLoyer() {
	locataire.payer(getLoyer());
	proprietaire.recevoir(getLoyer());
    }
}
