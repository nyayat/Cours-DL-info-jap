public class Batiment {
    private String adresse;
    private double surfaceHabitable;

    public String toString() {
        return "Adresse : " + adresse
	    + " surface habitable : " + surfaceHabitable;
    }

    // Exo 4.4
    // il faut implementer getSurface ici,
    // et getSurfaceJardin() dans la classe Maison
    public double getSurfaceHabitable() {
	return surfaceHabitable;
    }

    // Exo 4.6
    // taux d'imposition sur la surface habitable
    static final double tauxA = 5.6;

    // impostion sur un batiment simple (pas de jardin) sera redefinie pour la classe Maison
    public double impot() {
        return tauxA * surfaceHabitable;
    }

    // Exo 5.1 et 5.2
    protected Personne proprietaire;

    public Batiment(String adresse, double surface, Personne prop) {
        this.adresse = adresse;
        this.surfaceHabitable = surface;
        this.proprietaire = prop;
    }

    public void vendreA(Personne p) {
        proprietaire = p;
        p.acheter(this);
    }

}
