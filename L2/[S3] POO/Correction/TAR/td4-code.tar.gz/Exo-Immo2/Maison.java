public class Maison extends Batiment {
    private int nbPieces;
    private double surfaceJardin;
    
    public String toString() {
    	return super.toString()
	    + " nombre de pieces : " + nbPieces
	    + " surface jardin : " + surfaceJardin;
    }
    
    // Exo 4.4 
    public double getSurfaceJardin() {
	return surfaceJardin;
    }
    
    // Exo 4.6
    static final double tauxB = 1.5;

    // impostion sur une Maison, overriding 
    public double impot() { 
    	return super.impot() + tauxB * surfaceJardin;
    }

    // Exo 5.3
    private double loyer;
    public double getLoyer() {
	return loyer;
    }
    public void setLoyer(double l) {	
	this.loyer = l;
    }

    // Exo 5.1
    Maison(String adresse, int surfaceH, int surfaceJ, int nbPieces, Personne prop) {
    	super(adresse, surfaceH, prop);
    	this.nbPieces = nbPieces;
    	surfaceJardin = surfaceJ;
    }

}
