// Exo 5.5
public class Test {
     
     public static boolean chercherLocation(MaisonLouable[] t,
		     Personne locataire, double budget) {
     	for (var m : t) {
     		if (m.getLoyer() <= budget && !m.louee()) {
     			m.louerA(locataire);
			return true;
     		}
     	}
     	return false;
     }
     
     public static void main (String args[]) {}

}
