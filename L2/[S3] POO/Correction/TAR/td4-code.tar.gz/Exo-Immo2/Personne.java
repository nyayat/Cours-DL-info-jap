import java.util.*;

public class Personne {
    private String nom;
    private double argent;
    public Personne(String nom, double argent) {
    	this.nom = nom;
    	this.argent = argent;
    }
    
    // Exo 5.2
    private LinkedList<Batiment> biens;
    { biens = new LinkedList<Batiment>(); }
    private LinkedList<MaisonLouable> maisonsLouees;
    { maisonsLouees = new LinkedList<MaisonLouable>(); }
    
    public void louer(MaisonLouable m) {
    	maisonsLouees.add(m);
    }
    public void acheter(Batiment m) {
    	biens.add(m);
    }
    
    // Exo 5.3
    public void payer(double somme) {
	argent -= somme;
    }
    public void recevoir(double somme) {
	argent += somme;
    }
    
    // Exo 5.4
    public void payerImpots() {
    	for (var b : biens) { // l'odre des if est important
    	    if (b instanceof MaisonLouable) payer(1000);
	    else if (b instanceof Maison) payer(500);
	    else if (b instanceof Batiment) payer(200);
    	}
    }
}

