public class TestBatiment {

    public static void main (String args[]) {
        Batiment b = new Batiment("8 place de la Concorde", 600);
        Maison m1 = new Maison("13 rue Colbert", 200, 400, 10);
        Maison m2 = new Maison("42 rue de la Colline", 300, 500, 13);
        System.out.println(b);
        System.out.println(m1);
        System.out.println(m2);
        Batiment[] v = new Batiment[10];
        // Batiments pas instanciés, necessaire de le faire explicitement
        for(int i =0; i< 10; i++) {
        	v[i] = new Batiment("", 1000);
        }
        
        v[0] = m1;
        v[1] = m2;
        for(int i = 0; i < 10; i++) {
        	System.out.println(v[i]);
        }
        // affiche surface et adresse de chaque Batiment simple, et surface, adresse, 
        // surface jardin et nombre de pieces de chaque maison (dynamic binding sur toString()
        
        //Tests pour les exos de 4.4 à 4.6
        System.out.println(surfaceHabitableTotale(v));
        System.out.println(surfaceJardinTotale(v));
        for(int i = 0; i < 10; i++) {
        	System.out.println(v[i].impot());
        }

    }
	
    // Exo 4.5 La particularité des deux methodes suivantes  est qu'elles sont statiques 
    // car elles n'ont pas besoin d'un objet sur lequel travailler.
    
    public static double surfaceHabitableTotale(Batiment[] tabBat) {
    	double res = 0;
    	for (Batiment b : tabBat) {
    		if (b != null) {
    			res += b.getSurfaceHabitable();
    		}
    	}
    	return res ;   
    }
    
    public static double surfaceJardinTotale(Batiment[] tabBat) { 
    	double res = 0;
    	for (Batiment b : tabBat) {
    		if ((b != null) && (b instanceof Maison)) {
    			Maison m = (Maison) b;
    			res += m.getSurfaceJardin();
    		}
    	}
    	return res ;                
    }
}
