
public class Maison extends Batiment {
    private int nbPieces;
    private double surfaceJardin;
    Maison(String adresse, int surfaceH, int surfaceJ, int nbPieces) {
    	super(adresse, surfaceH);
    	this.nbPieces = nbPieces;
    	surfaceJardin = surfaceJ;
    }
    public String toString () {
    	return super.toString()
	    + " nombre de pieces : " + nbPieces
	    + " surface jardin : " + surfaceJardin;
    }
    
    //Exo 4.4 
    public double getSurfaceJardin() { return surfaceJardin; }
    
    //Exo 4.6
    static final double tauxB = 1.5;
    
    public double impot() { // impostion sur une Maison, overriding 
    	return super.impot() + tauxB * surfaceJardin;
    }


}
