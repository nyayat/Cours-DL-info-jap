public class Batiment {
    private String adresse;
    private double surfaceHabitable;
    public Batiment(String adresse, double surface) {
        this.adresse = adresse;
        this.surfaceHabitable = surface;
    }
    public String toString() {
        return "Adresse : " + adresse + " surface habitable : " + surfaceHabitable;
    }

    //Exo 4.4
    //il faut implementer getSurface ici, et getSurfaceJardin() dans la classe Maison
    public double getSurfaceHabitable() { return surfaceHabitable; }

    //Exo 4.6
    static final double tauxA = 5.6; // taux d'imposition sur la surface habitable

    public double impot() { // impostion sur un batiment simple (pas de jardin) sera redefinie pour la classe Maison
        return tauxA * surfaceHabitable;
    }

}
