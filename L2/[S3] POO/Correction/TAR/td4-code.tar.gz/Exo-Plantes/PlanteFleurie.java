/**
 *
 * @author berenice
 */
public class PlanteFleurie extends Plante {
    private static int nbPlanteSansEngrais;
    private boolean engrais=false;

    public PlanteFleurie() {
        nbPlanteSansEngrais++;
    }

    public String toString() {
        if (this.engrais) {
            return (super.toString() + " et j'ai eu de l'engrais");
        }
        else {
            return (super.toString() + " et j'ai besoin d'engrais");
        }
    }

    public static String Etat() {
        return (Plante.Etat() + "et il reste " + nbPlanteSansEngrais + " plantes sans engrais.");
    }


    public static void arrosage(PlanteFleurie p) { // attention ce n'est pas overriding mais surcharge
        Plante.arrosage(p);
        if (! p.engrais) {
                p.engrais = true;
                nbPlanteSansEngrais--;
        }
    }

/* // Dernière question :
    public void arrosage() { // ici on a bien overriding
        super.arrosage();
        if (! engrais) {
                engrais = true;
                nbPlanteSansEngrais--;
        }
    }*/



}
