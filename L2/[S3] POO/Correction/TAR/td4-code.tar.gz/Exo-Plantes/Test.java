public class Test {

    public static void main(String args[]) {
        Plante[] serre = new Plante[5];
	serre[0] = new Plante();
	serre[1] = new PlanteFleurie();
	serre[2] = new Plante();
	serre[3] = new PlanteFleurie();
	serre[4] = new Plante();
	System.out.println ( Plante.Etat() );
	System.out.println ( PlanteFleurie.Etat() );
	for(int i=0; i<5; i++) {
            Plante.arrosage(serre[i]); // serre[i] est de type declaré Plante, invocation de la methode Plante.arrosage(Plante)
            System.out.println(serre[i]);
            System.out.println(Plante.Etat());
            System.out.println(PlanteFleurie.Etat());
    	}
    }
}
/**
 * dernière question : remplacer Plante.arrosage ( serre [i] ) par serre[i].arrosage();
 * par dynamic binding si le type effectif est Plante, de l'eau sera donnée
 * alors que si le type effectif est PlanteFleurie, à la fois de l'eau et de l'engrais sera donné.
 */
