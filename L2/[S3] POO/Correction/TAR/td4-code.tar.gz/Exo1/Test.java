public class Test {
        public static void main(String[] args) {
                A a = new A();
                B b = new B();
                A c = new B();

                System.out.println("first block");
                a.g();
                b.g();
                c.g();
                                
                System.out.println();
                System.out.println("second block");
                a.f(a);
                a.f(b);
                a.f(c);
                b.f(a);
                b.f(b);
                b.f(c);
                c.f(a);
                c.f(b);
                c.f(c);
        }
}
