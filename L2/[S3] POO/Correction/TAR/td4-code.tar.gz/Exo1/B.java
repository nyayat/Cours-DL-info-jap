public class B extends A {
  @Override
  public void f(A x) {
    System.out.println("B.f(A)");
  }
  // Surcharge
  public void f(B x) {
    System.out.println("B.f(B)");
  }
}

