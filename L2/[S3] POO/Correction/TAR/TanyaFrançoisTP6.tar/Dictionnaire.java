/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author tanya
 */
public class Dictionnaire implements Triable {
    String[] dico;
    
    public Dictionnaire(int i){
        dico = new String [i];
    }
    
    @Override
    public void echange(int i, int j){
        String tmp = dico[i];
        dico[i]=dico[j];
        dico[j]=tmp;
    }
    
    @Override
    public boolean plusGrand(int i, int j){
        //System.out.println( dico[i].compareToIgnoreCase(dico[j]) );
        return dico[i].compareToIgnoreCase(dico[j])>0;
    }
    
    @Override
    public int taille(){
        return dico.length;
    }

    
    
}
