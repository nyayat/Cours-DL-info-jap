/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author tanya
 */
public class Triangle extends Figure implements Deformable {
    double base;
    double hauteur;
    
    public Triangle(int x, int y, double base, double hauteur){
        super(x,y);
        this.base = base;
        this.hauteur = hauteur;
    }
    
    @Override
    public void affiche(){
        System.out.print("figure : triangle, centre : ("+this.getPosX()+","+this.getPosY()+"), base :"+this.base+", hauteur : "+this.hauteur);
    }
    
    @Override
    public Figure deformation(double coeffH, double coeffV){
        coeffH = Math.abs(coeffH);
        coeffV = Math.abs(coeffV);
        return new Triangle(this.getPosX(), this.getPosY(), this.base*coeffH, this.hauteur*coeffV);
    }
    
    @Override
    public double surface(){
        return (base*hauteur)/2;
    }
    
}
