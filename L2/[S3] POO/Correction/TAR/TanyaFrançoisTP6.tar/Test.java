
import java.util.Arrays;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author tanya
 */
public class Test {
    public static void main(String[] args) {
        //Rectangle rec = new Rectangle (5,6,12,15);
        //rec.affiche();
        //System.out.println(rec.surface());
        //Rectangle rec2 = (Rectangle) rec.deformation(3,-6);
        //rec2.affiche();
        
        /*TabEntiersTriable t = new TabEntiersTriable(6);
        System.out.println(Arrays.toString(t.entier));
        
        Triable.triBulles(t);
        System.out.println(Arrays.toString(t.entier)); 
        
        TriBinaire t2 = new TriBinaire(6);
        System.out.println(Arrays.toString(t2.entier));
        
        Triable.triBulles(t2);
        System.out.println(Arrays.toString(t2.entier));*/
        
        
        
        Dictionnaire t3 = new Dictionnaire(6);
        t3.dico[0] = "ss";
        t3.dico[1] = "";
        t3.dico[2] = "ssa";
        t3.dico[3] = "tqaaa";
        t3.dico[4] = "t";
        t3.dico[5] = "bb";
        
        System.out.println(Arrays.toString(t3.dico));
        
        Triable.triBulles(t3);
        System.out.println(Arrays.toString(t3.dico));
        
        
        
    }
    
}
