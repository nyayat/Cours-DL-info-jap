/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author tanya
 */
public abstract class Figure {
    private int posX;
    private int posY;
    
    public Figure(int x, int y){
        posX = x;
        posY = y;
    }
    
    public int getPosX(){
        return this.posX;
    }
    
    public int getPosY(){
        return this.posY;
    }
    
    public abstract void affiche();
    
    public double estDistanceDe(Figure fig){
        return Math.sqrt( Math.pow((fig.posX-this.posX),2) + Math.pow((fig.posY-this.posY),2) );
    }
    
    public abstract double surface();
    
    public void deplacement(int x, int y){
        this.posX = x;
        this.posY = y;
    }
    
    
    
}
