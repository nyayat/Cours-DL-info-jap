/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author tanya
 */
public class TriBinaire implements Triable {    
    int[] entier;
    
    public TriBinaire(int i){
        entier = new int [i];
        int max = 10;
        int min = 1;
        int range = max - min + 1;
        
        for(int j=0; j<entier.length; j++){
            int nb = (int)( Math.random() * range ) + min ;
            String bin = Integer.toBinaryString(nb);
            entier[j]= Integer.parseInt(bin);
        }
    }
    
    @Override
    public void echange(int i, int j){
        int tmp = entier[i];
        entier[i]=entier[j];
        entier[j]=tmp;
    }
    
    @Override
    public boolean plusGrand(int i, int j){
        return entier[i]>entier[j];
    }
    
    @Override
    public int taille(){
        return entier.length;
    }
    
}
