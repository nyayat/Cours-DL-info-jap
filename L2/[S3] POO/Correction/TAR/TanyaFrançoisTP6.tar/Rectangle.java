/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author tanya
 */
public class Rectangle extends Figure implements Deformable {
    final double largeur;
    final double longueur;
    
    public Rectangle(int x, int y, double largeur, double longueur){
        super(x,y);
        this.largeur = largeur;
        this.longueur = longueur;
    }
    
    @Override
    public void affiche(){
        System.out.println("figure : rectangle, centre : ("+this.getPosX()+","+this.getPosY()+"), longueur :"+this.longueur+", largeur : "+this.largeur);
    }
    
    @Override
    public Figure deformation(double coeffH, double coeffV){
        coeffH = Math.abs(coeffH);
        coeffV = Math.abs(coeffV);
        return new Rectangle(this.getPosX(), this.getPosY(), this.largeur*coeffH, this.longueur*coeffV);
    }
    
    @Override
    public double surface(){
        return largeur*longueur;
    }
    
    
}
