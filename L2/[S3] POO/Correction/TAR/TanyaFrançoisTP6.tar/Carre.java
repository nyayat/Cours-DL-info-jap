/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author tanya
 */
public class Carre extends Rectangle {
    public Carre(int x, int y, double cote){
        super(x,y,cote,cote);
    }
    
    @Override
    public void affiche(){
        System.out.println("figure : carré, centre : ("+this.getPosX()+","+this.getPosY()+"), coté :"+this.longueur);
    }
    
}
