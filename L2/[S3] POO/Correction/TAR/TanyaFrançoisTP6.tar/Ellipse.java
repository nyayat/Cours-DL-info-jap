/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author tanya
 */
public class Ellipse extends Figure implements Deformable {
    final double gr;
    final double pr;
    
    public Ellipse(int x, int y, double grandRayon, double petitRayon){
        super(x,y);
        this.gr = grandRayon;
        this.pr = petitRayon;
    }
    
    @Override
    public void affiche(){
        System.out.println("figure : ellipse, centre : ("+this.getPosX()+","+this.getPosY()+"), Grand rayon :"+this.gr+", Petit rayon : "+this.pr);
    }
    
    @Override
    public Figure deformation(double coeffH, double coeffV){
        coeffH = Math.abs(coeffH);
        coeffV = Math.abs(coeffV);
        return new Ellipse(this.getPosX(), this.getPosY(), this.gr*coeffH, this.pr*coeffV);
    }
    
    @Override
    public double surface(){
        return Math.PI*gr*pr;
    }
    
}
