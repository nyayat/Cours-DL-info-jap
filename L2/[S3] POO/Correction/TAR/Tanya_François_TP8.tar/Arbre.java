
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author tanya
 */
public class Arbre {
        Noeud racine;

    private static class UnableToDeleteFileException extends Exception {

        public UnableToDeleteFileException() {
            System.out.print("Fichier non supprimé");
        }
    }
    
    public class Noeud {
        String nom;
        int taille;
        boolean repertoire;
        ArrayList<Noeud> fils;
        
        public Noeud (File f){
            try {
                if(!f.exists()){
                    throw new FileNotFoundException();
                }
                
                nom = f.getName();
                taille = (int)f.length();
                repertoire = f.isDirectory();
                
                if(repertoire){
                    File[] files = f.listFiles();
                    fils = new ArrayList<Noeud>();

                    for (File file : files) {
                        //System.out.println(file);
                        Noeud d = new Noeud(file);
                        fils.add(d);
                    }
                }
                else{
                    fils = null;
                }
               
            } 
            catch (FileNotFoundException e) {
                System.out.println("Erreur fichier");
            }
            
        }

        public void afficher(){
            
            
            for (Noeud fil : fils) {
                if(!fil.repertoire){System.out.print("    "); }
                
                System.out.println("  "+fil.nom +"["+fil.taille+"]");
                
                if(fil.repertoire){
                    fil.afficher();
                }
            }
        }
        
        public void map (StringTransformation t){
            fils.forEach(f-> {
                f.nom = t.transf(f.nom);
                
                if(f.repertoire){
                    f.map(t);
                }
                    
            });
        }

        public void traverser(String extension){
                       
            for (Noeud fil : fils) {
                if((fil.nom).endsWith("."+extension)){
                    System.out.println(fil.nom +"["+fil.taille+"]");
                }
                if(fil.repertoire){
                    fil.traverser(extension);
                    
                }
            }
            
        }
        
        public void supprimer(String extension) throws UnableToDeleteFileException{
                       
            /*for (Noeud fil : fils) {
                if((fil.nom).endsWith("."+extension)){
                    System.out.println(fil.nom);
                    if(!fils.remove(fil))throw new UnableToDeleteFileException();
                    
                }
                if(fil.repertoire){
                    fil.supprimer(extension);
                    
                }
            }*/
            
            for (int i=0; i<fils.size();i++){
                
                if( (fils.size()==1) && ( (fils.get(0).nom).endsWith("."+extension) ) ){
                    fils.clear();
                }
                
                if(!fils.isEmpty()){
                    
                
                if(fils.get(i).repertoire){
                    fils.get(i).supprimer(extension);

                    }
                if((fils.get(i).nom).endsWith("."+extension)){
                    if(!fils.remove(fils.get(i)))throw new UnableToDeleteFileException();
                    if(i>0){ i--; }
                    else{ i=-1; }
                    }
                
                }
                
            }
        }
    }
    
    public Arbre(String chemin){
        racine = new Noeud(new File(chemin));        
    }
    
    public void afficher(){
        System.out.println(racine.nom +"["+racine.taille+"]");
        racine.afficher();
    }
    
    public void map(StringTransformation t){
        racine.map(t);
    }
    
    public void traverser(String extension){
        racine.traverser(extension);
        
    }
    
    public void supprimer (String extension) throws UnableToDeleteFileException{
        racine.supprimer(extension);
        
    }
    
}
