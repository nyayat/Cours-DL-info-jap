
import java.io.File;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author tanya
 */
public class Test {
    
    public static void main(String[] args) {
        //String basePath = new File("").getAbsolutePath();
        //System.out.println(basePath);
        Arbre a = new Arbre("/home/tanya/Bureau/tptest");
        
        //IV.1)
        
        StringTransformation addBlah = (String chaine) -> {
            return (chaine+".blah");
        };
        
        /*
        String test = "bonjour.";
        System.out.println(addBlah.transf(test));*/
        
        //a.map(addBlah);
        
        //a.afficher();
        
        //a.traverser("jpg");
        
        a.supprimer("jpg");
        a.afficher();
        
        
        
    }
    
}
