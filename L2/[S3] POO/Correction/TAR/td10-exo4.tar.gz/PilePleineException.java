public class PilePleineException extends Exception {
  PilePleineException() {
    super("Pile pleine");
  }
}
