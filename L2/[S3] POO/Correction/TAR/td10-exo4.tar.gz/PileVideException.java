public class PileVideException extends Exception {
  PileVideException() {
    super("Pile vide");
  }
}
