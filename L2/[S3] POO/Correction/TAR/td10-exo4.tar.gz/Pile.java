import java.util.*;

public class Pile<T> {
  private Object[] items;
  private int top = -1;

  public Pile(int taille) {
    if (taille < 0) throw new IllegalArgumentException();
    items = new Object[taille];
    top = -1;
  }

  public void empile(T item) throws PilePleineException {
    if (top == items.length - 1) throw new PilePleineException();
    items[++top] = item; // conversion de T à Object : implicite
  }

  public T depile() throws PileVideException {
    if (top < 0) throw new PileVideException();
    Object item = items[top--];
    return (T) item; // conversion de Object à T. Genere un warning :
    // rien ne garantit que items contient des elements de type T
  }

  public T getSommet() throws PileVideException {
    if (top < 0) throw new PileVideException();
    return (T) items[top]; // conversion de Object à T. Genere un warning :
    // rien ne garantit que items contient des elements de type T
  }

  public boolean estVide() {
    return top == -1;
  }

  public boolean estPleine() {
    return top == items.length - 1;
  }

  /**
   * Main method for command-line invocation.
   *
   * @param args the argument String array
   */
  public static void main(String args[]) {
    var p = new Pile<Integer>(10);
    try {
      for (int i = 0; i <= 11; i++) p.empile(i);
    } catch (PilePleineException e) {
      System.out.println(e.getMessage());
    }
    try {
      while (!p.estVide()) System.out.println(p.depile());
      p.getSommet();
    } catch (PileVideException e) {
      System.out.println(e.getMessage());
    }
  }
}
