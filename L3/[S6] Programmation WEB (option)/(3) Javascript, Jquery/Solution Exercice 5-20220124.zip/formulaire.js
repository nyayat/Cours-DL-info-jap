$(document).ready( function() {

    var nom = $("input[name=nom]");
    var prenom = $("input[name=prenom]");
    var civil = $("select[name=civil]");
    var complet = $("input[name=complet]");

    // Nom complet en fonction des champs prenom et nom
    function nomComplet () {
	complet.val (civil.val () + " " + prenom.val () + " " + nom.val ());
    };
    nom.change (nomComplet);
    prenom.change (nomComplet);
    civil.change (nomComplet);

    // Afficher la valeur du niveau javascript
    $("output[name=niv]").val ($("input[name=niveau]").val ());
    $("input[name=niveau]").change (function () {
        $("output[name=niv]").val ($("input[name=niveau]").val ())
    });

    // mdp clair ou non selon checkbox
    var mdp = $('input[name=mdp]');
    var mdp2 = $('input[name=mdp2]');
    function mdpClair () {
        if ($("#checkbox").prop ("checked")) {
            mdp.attr ('type', 'text');
            mdp2.attr ('type', 'text');
        }
        else {
            mdp.attr ('type','password');
            mdp2.attr ('type','password');
        }
    }
    $("#checkbox").change (mdpClair);

    // Désactiver Submit si un champ est vide et mettre en rouge les labels des champs vides
    var input = $('.nonVide');
    var bouton = $('#envoi');
    bouton.attr ('disabled', true);
    input.change (function () {
	var trigger = false;
        input.each (function () {
            if (!$(this).val ()) {
		trigger = true;
		$(this).prev ().css ({"color":"red"});
            }
            else
            {
		$(this).prev ().css ({"color":"black"});
            }
        });
	if (mdp.val () != mdp2.val ()) {
            mdp2.prev ().css ({"color":"red"});
            trigger = true;
	}
	trigger ?
	    bouton.attr ('disabled', true) :
	    bouton.removeAttr('disabled');
    });

    // Max et min pour la date de naissance (attention au format !)
    var d = new Date();
    var day = ("0"+(d.getDate())).slice(-2)
    var month = ("0" + (d.getMonth()+1)).slice(-2)
    var dmax = d.getFullYear() + "-"
	+ month + "-" + day;
    var dmin = (d.getFullYear()-100) + "-"
	+ month + "-" + day;
    $('#date').attr({'max':dmax, 'min':dmin});

    // Si on vient de Submit, afficher les infos
    $('#envoi').click (function () {
	var nc = complet.val ();
	var dn = $('#date').val ();
	$('form').html ("<p>Bonjour " + nc + ". Vous êtes né le " + dn + "</p>");
    });
    
});
