Vue.component('message', {
    props: ['descriptor', 'globals'],
    data: function () {
        return {
            liked: false
        }
    },
    methods: {
        visible: function () {
            return this.liked || !this.globals.onlyLiked;
        }
    },
    computed: {
        since: function () {
            return this.globals.now - this.descriptor.date;
        }
    },
    template: `
    <div v-if="visible()">
            <span>(<input type="checkbox" v-model="liked"> J'aime !)</span>
        <span>
            Il y a {{Math.trunc(since/1000)}} secondes : {{ descriptor.content }}
        </span>
    </div>`
}
)


var app = new Vue({
    el: '#app',
    data: function () {
        return {
            seen: false,
            messages: [],
            addMessage: '',
            globals: {
                onlyLiked: false,
                now: Date.now()
            }
        }
    },
    mounted: function () {
        setInterval(() => { this.globals.now = Date.now(); }, 1000);
    },
    methods: {
        onSubmit: function (event) {
            this.messages.push({
                content: this.addMessage, date: Date.now()
            });
            this.addMessage = '';
        }
    }
})
