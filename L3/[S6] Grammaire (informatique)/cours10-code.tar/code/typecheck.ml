open Syntaxe

exception Error of string

let rec get_declarations = function
  | [] -> []
  | (v,t)::r ->
     let dr = get_declarations r in
     if List.mem_assoc v r
     then raise (Error ("Variable deux fois declarée : "^v))
     else (v,t)::dr

let rec type_expression env = function
  | Const _ -> Int
  | Ident x -> begin
      try List.assoc x env
      with Not_found -> raise (Error ("Variable pas declarée : " ^ x))
    end
  | App(e1,o,e2) ->
     let t1 = type_expression env e1
     and t2 = type_expression env e2
     in match o with
        | Plus -> if t1=Int && t2=Int
                  then Int
                  else raise (Error "Erreur de typage Plus")
        | Mult -> if t1=Int && t2=Int
                  then Int
                  else raise (Error "Erreur de typage Mult")
        | And -> if t1=Bool && t2=Bool
                  then Bool
                  else raise (Error "Erreur de typage And")
        | Or -> if t1=Bool && t2=Bool
                  then Bool
                  else raise (Error "Erreur de typage Or")
        | Egal -> if t1=t2
                  then Bool
                  else raise (Error "Erreur de typage Egal")

let rec check_instruction env = function
  | Affect(v,e) -> if List.assoc v env = type_expression env e
                   then ()
                   else raise (Error "type incohérent dans une affectation")
  | Print e -> if type_expression env e = Int
               then ()
               else  raise (Error "type incohérent dans un affichage")
  | Cond(e,il) ->
     if type_expression env e = Bool
     then check_instlist env il
     else  raise (Error "expression entière comme condition")
and check_instlist env il =
  List.iter (check_instruction env) il
      
let check_program (ds,il) =
  check_instlist (get_declarations ds) il
