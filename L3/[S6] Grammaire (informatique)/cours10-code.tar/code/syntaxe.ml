(* Syntaxe abstraite *)

type op = Plus | Mult | Egal | And | Or

type expression =
  | Const of int
  | Ident of string
  | App of expression * op * expression

type instruction =
  | Affect of string * expression
  | Print of expression
  | Cond of expression * instruction list

type typ = Bool | Int
   
type declaration = string * typ 

type program = declaration list * instruction list
