open Tree
open Reader
   
exception Error of string
let rec parse_F () = 
  match lookahead () with
  | Ch 'a' -> begin (* F -> a *)
      eat (Ch 'a');
      Node("F",[Leaf 'a'])
    end
  | _ -> raise (Error "parsing F")
and parse_S () =
  match lookahead () with
  | Ch 'a' -> begin (* S -> F *)
      let x = parse_F () in
      Node("S",[x])
    end
  | Ch '(' -> begin (* S -> (F+S) *)
      eat (Ch '(');
      let x1 = parse_F () in
      eat (Ch '+');
      let x2 = parse_S () in
      eat (Ch ')');
      Node("S",[Leaf '(';x1;Leaf '+'; x2; Leaf ')'])
    end
  | _ -> raise (Error "parsing S")
and parse_Sprime () =
  match lookahead () with
  | Ch 'a' | Ch '(' -> begin (* S' -> S EOF *)
      let x = parse_S () in
      eat EOF;
      Node("Sprime",[x; Leaf '#'])
    end
  | _ -> raise (Error "parsing Sprime")
       
let parse () = parse_Sprime ()
                 
