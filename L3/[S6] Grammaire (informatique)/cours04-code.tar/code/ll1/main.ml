Tree.print (Parser.parse ())
