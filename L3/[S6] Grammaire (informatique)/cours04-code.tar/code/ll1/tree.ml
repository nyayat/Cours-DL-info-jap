type t =
  | Node of string * t list
  | Leaf of char

let rec print_aux pref = function
  | Node(label,l) ->
     print_string (pref^label^"\n");
     List.iter (print_aux (pref^"  ")) l;
  | Leaf label -> print_string (pref^(String.make 1 label)^"\n")

let print t = print_aux "" t
