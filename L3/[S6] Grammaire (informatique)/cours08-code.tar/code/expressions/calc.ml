(* programme principal *)

open Syntax
   
let rec evaluate = function
  | Const i -> i
  | App(e1,Plus,e2) -> (evaluate e1) + (evaluate e2)
  | App(e1,Mult,e2) -> (evaluate e1) * (evaluate e2)
;;

let ast = Parser.s Lexer.token
            (Lexing.from_channel stdin)
    in Printf.printf "Résultat : %i\n" (evaluate ast)
