(* Syntaxe abstraite des expressions arithmétiques *)

type op = Plus | Mult
type t = Const of int | App of t * op * t
                                     
