(* Syntaxe abstraite des expressions arithmétiques *)

type op = Plus | Mult
type t = Const of int | App of op * t list

let eval = function Plus -> (+) | Mult -> ( * )
let neutre = function Plus -> 0 | Mult -> 1
                                        
let rec calc = function
  | Const(i) -> i
  | App(o,l) -> List.fold_left
                  (fun a x -> (eval o) a (calc x))
                  (neutre o) l
                                     
