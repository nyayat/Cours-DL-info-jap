(* Syntaxe abstraite des expressions arithmétiques *)

type op = Plus | Mult
type t = Const of int | App of t * op * t

let ots = function
  | Plus -> "+"
  | Mult -> "*"
          
let rec to_string = function
  | Const(i) -> string_of_int i
  | App(e1,o,e2) -> ots(o)^"("^(to_string e1)^","^(to_string e2)^")"
                                     
