(* programme principal *)

open Syntax;;
   
let ast = Parser.s Lexer.token
            (Lexing.from_channel stdin)
    in Printf.printf "Abstract Syntax Tree : %s\n" (to_string ast)
         
