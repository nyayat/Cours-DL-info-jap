open Tree
open Reader
   
exception Error of string
let rec parse_S () =
  match lookahead () with
  | Ch 'i' | Ch '(' -> begin (* S -> E *)
      let x = parse_E () in
      Node("S",[x])
    end
  | _ -> raise (Error "parsing S")
and parse_E () =
  match lookahead () with
  | Ch 'i' | Ch '(' -> begin (* E -> T E' *)
      let x1 = parse_T () in
      let x2 = parse_Eprime () in
      Node("E",[x1;x2])
    end
  | _ -> raise (Error "parsing E")
and parse_Eprime () =
  match lookahead () with
  | Ch ')' | EOF -> (* E' -> epsilon *)
     Node("E'",[Epsilon])
  | Ch '+' -> begin (* E' -> + E *)
      eat (Ch '+');
      let x = parse_E () in
      Node("E'",[Leaf '+';x])
    end
  | _ -> raise (Error "parsing E'")
and parse_T () =
  match lookahead () with
  | Ch 'i' | Ch '(' -> begin (* T -> F T' *)
      let x1 = parse_F () in
      let x2 = parse_Tprime () in
      Node("T",[x1;x2])
    end
  | _ -> raise (Error "parsing T")
and parse_Tprime () =
  match lookahead () with
  | Ch ')' | Ch '+' | EOF -> (* T' -> epsilon *)
     Node("T'",[Epsilon])
  | Ch '*' -> begin (* T' -> * T *)
      eat (Ch '*');
      let x = parse_T () in
      Node("T'",[Leaf '*';x])
    end
  | _ -> raise (Error "parsing E'")
and parse_F () = 
  match lookahead () with
  | Ch '(' -> begin (* F -> ( E ) *)
      eat (Ch '(');
      let x = parse_E () in
      eat (Ch ')');
      Node("F",[Leaf '(';x;Leaf ')'])
    end
  | Ch 'i' -> begin (* F -> i *)
      eat (Ch 'i');
      Node("F",[Leaf 'i'])
    end
  | _ -> raise (Error "parsing F")
       
let parse () = parse_S ()
                 
