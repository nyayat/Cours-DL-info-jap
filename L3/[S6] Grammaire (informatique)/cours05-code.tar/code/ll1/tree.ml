open Graphics;;

open_graph ""
   
type t =
  | Node of string * t list
  | Leaf of char
  | Epsilon

type t_sized =
  (* Node(node_label, list_of_children, width, height) *)
  | Node_sized of string * t_sized list * int * int

let windowmargin = 30  (* horizontal and vertical margins *)
let levelsep = 60      (* vertical distance between levels *)
let childrensep = 40   (* horizontal distance between trees *)
let node_edge_sep = 5  (* vertical seperation between node and edge *)

(* calculate width and height of a tree *)
let rec size = function
  | Leaf c -> let label = String.make 1 c in
              let (label_w,label_h) = Graphics.text_size label in
              Node_sized (label,[],label_w,label_h)
  | Epsilon ->  let label = "eps" in
                let (label_w,label_h) = Graphics.text_size label in
                Node_sized (label,[],label_w,label_h)
  | Node(label,children) ->
     let (label_w,label_h) = Graphics.text_size label in
     let number_of_children = List.length children in
     if number_of_children = 0
     then Node_sized(label,[],label_w,label_h)
     else
       let children_sized = List.map size children in
       let children_h =
         List.fold_left max 0
           (List.map (function Node_sized(_,_,_,h) -> h) children_sized)
       and children_w =
         List.fold_left
           (+) ((number_of_children-1)*childrensep)
           (List.map (function Node_sized(_,_,w,_) -> w) children_sized)
       in Node_sized(label,children_sized,
                     max label_w children_w,
                     children_h+levelsep+label_h)

(* (draw x y t) draws the sized tree t in a virtual box with upper left *)
(* corner at position (x,y). Returns ().                                *)
let rec draw x y (Node_sized(label,children,width,height)) =
  let (label_w,label_h) = text_size label in
  moveto (x+width/2-label_w/2) (y-label_h);
  draw_string label;
  (* departure point of the edges to the children *)
  let dep_x = x+width/2
  and dep_y = y-label_h-node_edge_sep in
  ignore(List.fold_left
           (fun x_child (Node_sized(_,_,child_w,_) as child)  ->
             begin
               draw x_child (y-levelsep-label_h) child;
               moveto dep_x dep_y;
               lineto (x_child+child_w/2) (dep_y-levelsep+node_edge_sep);
               x_child+child_w+childrensep
             end)
           x
           children)
 
let display tree =
  let tree_sized = size tree in
  let Node_sized(_,_,w,h) = tree_sized in
  begin
    resize_window (w+2*windowmargin) (h+2*windowmargin);
    ignore (draw windowmargin (h+windowmargin) tree_sized);
    while true do
      if (wait_next_event [Key_pressed]).key = 'q'
      then begin close_graph (); exit 0 end
    done
  end

