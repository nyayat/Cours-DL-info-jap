Tree.display (Parser.parse ())
