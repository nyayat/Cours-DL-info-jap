
type def = string * expression
and               
expression =
  | Int of int
  | Plus of expression * expression

let rec 
    as_string = function
    | Int x -> string_of_int x
    | Plus (l, r) -> apply "+" l r

  and apply op l r = 
    "(" ^ as_string l  ^ op ^  as_string r ^ ")"
