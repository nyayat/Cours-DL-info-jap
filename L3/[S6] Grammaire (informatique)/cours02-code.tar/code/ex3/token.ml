type token =
  | INT of int
  | EOF

let to_string = function
  | INT(n) -> "INT("^(string_of_int n)^")"
  | EOF -> "EOF"
