type token =
  | INT of int
  | ID of string
  | PARG
  | PARD
  | MULT
  | PLUS
  | EOF

let to_string = function
  | INT(n) -> "INT("^(string_of_int n)^")"
  | ID(s) -> "ID("^s^")"
  | PARG -> "PARG"
  | PARD -> "PARD"
  | MULT -> "MULT"
  | PLUS -> "PLUS"
  | EOF -> "EOF"
