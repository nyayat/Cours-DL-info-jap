type token =
  | INT of int
  | ID of string
  | BEGIN
  | END
  | CLASS
  | EOF

let to_string = function
  | INT(n) -> "INT("^(string_of_int n)^")"
  | ID(s) -> "ID("^s^")"
  | BEGIN -> "BEGIN"
  | END  -> "END"
  | CLASS -> "CLASS"
  | EOF -> "EOF"
