let ch = open_in (Sys.argv.(1)) in
    let lb = Lexing.from_channel ch
    in
    try
      while true do
        let t = Arith.next_token lb 
        in
        Printf.printf "%s\n" (Token.to_string t);
        if t=Token.EOF then exit 0
      done
    with
      Arith.Lexing_error s ->
      Printf.printf "Unexpected character: %s\n" s
