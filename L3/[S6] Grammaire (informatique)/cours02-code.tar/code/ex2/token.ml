type token =
  | BRINT of int
  | EOF

let to_string = function
  | BRINT(n) -> "BRINT("^(string_of_int n)^")"
  | EOF -> "EOF"
