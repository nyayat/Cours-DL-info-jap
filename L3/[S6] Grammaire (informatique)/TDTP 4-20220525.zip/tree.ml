type t =
  | Node of string * t list
  | Leaf of char

let rec to_string = function
  | Node(label,[]) -> label
  | Node(label,h::r) -> (List.fold_left
                           (fun a t -> a^","^(to_string t))
                           (label^"("^(to_string h))
                           r
                        )^")"
  | Leaf label -> String.make 1 label                           
                                                                           
