print_string (Tree.to_string (Parser.parse ())^"\n")
