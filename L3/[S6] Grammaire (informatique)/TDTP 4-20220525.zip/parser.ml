(* Z -> S $
   S -> O E
   O -> g | p
   E -> iK
   K -> -E | +E | d
 *)                  
open Tree                    
open Reader
   
exception Error of string
let rec parse_Z () = let x = parse_S () in eat EOF; x
                        
and parse_S () =              
  match lookahead () with
  | Ch 'g' | Ch 'p'
    ->  let x1 = parse_O () in
        let x2 = parse_E () in
        Node ("S",[x1;x2])
  | _ -> raise (Error "parsing S")
and parse_O () =        (* O -> g | p *)
  match lookahead () with
  | Ch 'g' -> eat (Ch 'g'); Node ("O", [Leaf 'g'])
  | Ch 'p' -> failwith "Students, this is your job ! "
  | _ -> raise (Error "parsing O")

and parse_E () = (* E -> iK *)
  eat (Ch 'i'); let x = parse_K() in Node ("E", [Leaf 'i'; x])
  
and parse_K () = failwith "Students, this is your job !"
  
let parse () = parse_Z ()
