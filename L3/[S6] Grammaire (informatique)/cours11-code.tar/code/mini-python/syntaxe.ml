type binop = Plus | Mult | And | Or | Equal | Greater

type expression =
  | Binapp of binop*expression*expression
  | Ident of string
  | Bool of bool
  | Int of int

type instruction =
  | Cond of expression * instruction list
  | Print of expression
  | Affect of string*expression

type program = instruction list
