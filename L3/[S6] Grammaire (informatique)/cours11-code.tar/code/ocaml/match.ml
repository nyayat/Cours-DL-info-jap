type t = A of t | B of t | C of t | I of int

let f x = match x with
  | A y -> true
  | B y -> match y with
           | A z -> false
           | B z -> true
           | C z -> false
           | I n -> true
  | C y -> false
  | I n -> true

