#!/usr/bin/python3

print(32)
if x > 17 :
    print(x)
    if x > 42 :
        print(x+x)
 print(x*x)
 
