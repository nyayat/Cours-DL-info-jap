#!/usr/bin/python3

x=42
if x > 1 :
    print("niveau 1")
    if x > 10 :
        print("niveau 2")
print("niveau 0")
