#!/usr/bin/python3

if x > 42 :
    print(x)
     print(x+x)
    print(x*x
