#!/usr/bin/python3
# erreur de typage seulement detectee quand
# la branche else est executee

import sys
while True:
    read=sys.stdin.readline()
    if read != 'coocoo\n':
        print(17+21)
    else:
        print ('abc' & 'def')
