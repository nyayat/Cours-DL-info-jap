#!/usr/bin/python3
# erreur de syntaxe detectee avant execution

print("hello")
print("bonjour")
if fi
