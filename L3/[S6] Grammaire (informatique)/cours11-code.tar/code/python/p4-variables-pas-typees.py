#!/usr/bin/python3
# la meme variable peut prendre des valeurs de
# type different.

x=42
print(x)
x=True
print(x)
