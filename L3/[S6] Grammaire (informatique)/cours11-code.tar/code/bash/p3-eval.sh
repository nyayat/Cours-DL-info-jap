#!/bin/bash
# évaluation d'une chaîne construite pendant
# l'exécution du programme.

i=10

mot="if (( i > 0 )); then echo 'if'; ((i--)); fi"
eval $mot

mot=$(sed -e 's/if/while/g' -e 's/then/do/' \
          -e 's/fi/done/' <<< $mot)
eval "$mot"
