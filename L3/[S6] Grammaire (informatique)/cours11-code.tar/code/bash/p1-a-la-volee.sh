#!/bin/bash
# les deux premières lignes sont exécutées avant
# que l'erreur de syntaxe est detectée.

echo "hello"
echo "bonjour"
if fi
