#!/bin/bash

for do in for do in echo done; do echo $do; done 
