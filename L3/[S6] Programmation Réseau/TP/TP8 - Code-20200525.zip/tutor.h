#ifndef TP8_CODE_TUTEURS_H_
#define TP8_CODE_TUTEURS_H_

#define _CMD_LIST  "LIST"
#define _CMD_ACQ_S "ACQUIRE"
#define _CMD_REL   "RELEASE"
#define _CMD_QUIT  "QUIT"
#define _MSG_ALREADY_ASSIGNED   "TUTOR_ALREADY_ASSIGNED"
#define _MSG_NOT_ASSIGNED "TUTOR_NOT_ASSIGNED"
#define _MSG_NOT_AVAILABLE "TUTOR_NOT_AVAILABLE"
#define _MSG_ERR   "ERROR"
#define _MSG_MAXLENGTH 100
#define _RPLY_MAXMSGS 100

#define _SRV_PORT  7783


// Datatype
struct tutor {
	char id[100];
	char subj[100];
	struct tutor *next;
};

struct assignment{
  struct tutor* moniteur;
  int id_student;
  struct assignment *next;
};

/*
 * Initialize a tutor list from a file.
 * @param[in]	filepath	The path of the file
 * @param[out]	tutors  	The head of the tutor list
 */
int init_tutors(char *, struct tutor **);

/*
 * Copy a tutors list
 * @param[in]	tutors  	The head of the tutor list to be copied
 * @return					The head of the copy of list
 */
struct tutor *copy(struct tutor *);

/*
 * Assign a tutor to a student.
 * @param[in]	tutors  	The head of the tutor list
 * @param[in] assignments The head of the assignement list
 * @param[in] subject The name of the subject to be assigned
 * @param[in] id The identifier of the student (for instance the socket used in
 * the connection)
 * @return  The pointer to the created assignement. This assignement is already
 * included in the asignment list. If the assignment was not possible, NULL is
 * returned.
 */
struct assignment* assign(struct tutor**, struct assignment**, char *, int);

/*
 * Checks if a tutor can be assigned to a student.
 * @param[in] assignments The head of the assignement list
 * @param[in] id The identifier of the student (for instance the socket used in
 * the connection)
 * @return  If the student has already a ongoing assignement.
 */
int can_assign(struct assignment*, int);

/*
 * Release the tutor from a student
 * @param[in]	tutors  	The head of the tutor list
 * @param[in] assignments The head of the assignement list
 * @param[in] id The identifier of the student (for instance the socket used in
 * the connection)
 * @return  If the release of the tutor was possible.
 */
int release(struct tutor**, struct assignment**, int);

/*
 * Print a list of tutors.
 * @param[in]	tutors  	The head of the tutor list
 */
void print_tutors(struct tutor*);

/*
 * Print a list of assignments
 * @param[in] assignments The head of the assignement list
 */
void print_assignments(struct assignment*);


#endif /* TP8_CODE_TUTEURS_H_ */
