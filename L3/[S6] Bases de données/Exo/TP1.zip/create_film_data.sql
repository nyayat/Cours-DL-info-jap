
insert into cinema (codeCinema, nom, ville,nbSalles) values 
(1, 'Chaplin Denfert', 'Paris',1);
insert into cinema (codeCinema, nom, ville,nbSalles) values 
(2, 'Studio des Ursulines', 'Paris',2);
insert into cinema (codeCinema, nom, ville,nbSalles) values 
(3, 'MK2 Bibliotheque', 'Paris',12);
insert into cinema (codeCinema, nom, ville,nbSalles) values 
(4, 'L''escurial', 'Paris',1);
insert into cinema (codeCinema, nom, ville,nbSalles) values 
(5, 'L''autre cinema', 'Marseille',0);
insert into cinema (codeCinema, nom, ville,nbSalles) values 
(6, 'L''autre cinema', 'Nice',5);
insert into cinema (codeCinema, nom, ville,nbSalles) values 
(7, 'La vidéothèque', 'Nice', NULL);

insert into film(codefilm, titre, annee) values
(1,'Le Voyage de Chihiro', 2001);
insert into artiste(codeartiste, nom, prenom)
values (1,'Miyazaki','Hayao');
insert into tourne(codeartiste, codefilm) values
(1,1);

insert into film(codefilm, titre, annee) values
(2, 'Les Enfants Loups', 2012);
insert into artiste(codeartiste, nom, prenom)
values (2,'Hosoda','Mamoru');
insert into tourne(codeartiste, codefilm) values
(2,2);

insert into film(codefilm, titre, annee) values
(3, 'Max et les maximonstres', 2009);
insert into artiste(codeartiste, nom, prenom)
values (3,'Jonze','Spike');
insert into tourne(codeartiste, codefilm) values
(3,3);

insert into film(codefilm, titre, annee) values
(4, 'Kiki la petite sorcière', 1989);
insert into tourne(codeartiste, codefilm) values
(1,4);

insert into passe(codefilm, codecinema)
values(1,2);
insert into passe(codefilm, codecinema)
values(1,4);
insert into passe(codefilm, codecinema)
values(2,2);
insert into passe(codefilm, codecinema)
values(3,1);



insert into joue(codeartiste,codeFilm,cachet) values(3,1,560) ;
insert into joue(codeartiste,codeFilm,cachet) values(3,2,4770);
insert into joue(codeartiste,codeFilm,cachet) values(3,3,6587);
insert into joue(codeartiste,codeFilm,cachet) values(2,1,456);
insert into joue(codeartiste,codeFilm,cachet) values(2,2,67);
insert into joue(codeartiste,codeFilm,cachet) values(2,3,4560);
