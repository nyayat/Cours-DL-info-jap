------------------à
-- BD Bioinfo
-- TP1 Exercice 1
-- Auteur: S Laplante
-- Modifié par : XXXXX
------------------

-- Ajouter les contraintes et modifier pour en faire un script qui s'execute sans erreur...

CREATE TABLE employes(
   nom VARCHAR,
   prenom VARCHAR,
   grade INTEGER ,
   poste VARCHAR 
);

CREATE TABLE salaire(
   grade INTEGER ,
   salaire INTEGER 
);



insert into employes values ('Martin', 'Paul', 3, 'Salle');
insert into employes values ('Legrand', 'Marcel', 2, 'Salle');
insert into employes values ('Durand', 'Laetitia', 1, 'Salle');
insert into employes values ('Legrand', 'Madeleine', 3, 'Salle');
insert into employes values ('Martin', 'Pierre', 3, 'Cuisine');
insert into employes values ('Duval', 'Patricia', 2, 'Cuisine');
insert into employes values ('Legrand', 'Marie', 3, 'Cuisine');




insert into salaire values(3, 1600);
insert into salaire values(1, 1200);
insert into salaire values(2, 1400);
