------------------à
-- BD Bioinfo
-- TP1 Exercice 2
-- Auteur: S Laplante
-- Modifié par : XXXXX
------------------

DROP TABLE PASSE;
DROP TABLE TOURNE;
DROP TABLE JOUE;
DROP TABLE CINEMA;
DROP TABLE ARTISTE;
DROP TABLE FILM;

CREATE TABLE FILM (
  codefilm integer PRIMARY KEY,
  titre text,
  annee integer
);

CREATE TABLE ARTISTE (
  codeartiste integer PRIMARY KEY,
  nom varchar(20),
  prenom VARCHAR(20),
  dateNaissance DATE,
  adresse text
);

CREATE TABLE CINEMA (
  codecinema integer PRIMARY KEY,
  nom varchar(20),
  ville varchar(20),
  adresse text,
  nbSalles integer CHECK (nbSalles>=0) 
);

CREATE TABLE JOUE(
  codeartiste integer references ARTISTE,
  codeFilm integer references FILM, 
  cachet integer
);

CREATE TABLE TOURNE (
  codeArtiste integer references ARTISTE,
  codeFIlm integer references FILM, 
  budget integer,
  PRIMARY KEY(codeArtiste, codeFilm)
);

CREATE TABLE PASSE (
  codeFILM INTEGER REFERENCES FILM,
  CodeCinema INTEGER REFERENCES CINEMA,
  dateDebut DATE,
  dateFin DATE,
  CHECK (dateDebut<= dateFin),
  PRIMARY KEY(CodeFilm, CodeCinema)
);



-- Une fois les tables créées correctement retirer le commentaire pour peupler les tables
-- \i create_film_data

