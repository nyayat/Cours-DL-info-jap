DROP TABLE IF EXISTS Notes;
DROP TABLE IF EXISTS Controles;
DROP TABLE IF EXISTS Matieres;
DROP TABLE IF EXISTS Etudiants;

CREATE TABLE Etudiants (
Num_Etu INTEGER PRIMARY KEY,
Nom     VARCHAR NOT NULL,
Prenom  VARCHAR NOT NULL
);

CREATE TABLE Matieres (
Id_Mat VARCHAR PRIMARY KEY,
Nom    VARCHAR NOT NULL
);

CREATE TABLE Controles (
Id_Controle   INTEGER NOT NULL PRIMARY KEY,
Id_Mat        VARCHAR NOT NULL REFERENCES Matieres,
Date_Controle DATE
);

CREATE TABLE Notes (
Num_Etu     INTEGER REFERENCES Etudiants,
id_Controle INTEGER REFERENCES Controles,
Note        INTEGER CHECK (Note BETWEEN 0 and 20)
);

INSERT INTO Etudiants (Num_Etu, Nom, Prenom) VALUES
(1, 'Huilda', 'Rachid'),
(2, 'Marolex', 'Eléonor'),
(3, 'Tartine', 'Kimberley'),
(4, 'Honnête', 'Camille')
;

INSERT INTO Matieres(Id_Mat, Nom) VALUES
(1, 'Mathematiques')
;

INSERT INTO Controles(Id_Controle, Id_Mat, Date_Controle) VALUES
(11,1, '01-01-1927'),
(12,1, '01-06-1934')
;


INSERT INTO Notes(Num_Etu, Id_Controle, Note) VALUES
(3,11, 18),
(4,11, 0),
(1,11,17),
(2,11,2),
(3,12, 20),
(4,12, 5),
(1,12,20),
(2,12,8)
;

