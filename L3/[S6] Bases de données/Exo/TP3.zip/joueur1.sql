INSERT INTO joueurs (nom, prenom, dateDeNaissance, nationalite) VALUES 
('Sanchez','Federico','1988-10-26','Argentine'),
('Goromaru','Aymuru','1986-03-01','Japon'),
('Foley','Bernard','1989-09-08','Australie'),
('Pollard','Handré','1994-03-11','Afrique du Sud'),
('Biggar','Dan','1989-10-16','Pays de Galles'),
('Farrel','Owen','1991-09-24','Angleterre'),
('Michalak','Frederic','1982-10-16','France'),
('Laidlaw','Greig','1985-10-12','Ecosse'),
('Tommaso','Allan','1993-04-26','Ecosse'),
('Jaziri','Samy','1970-01-30','France');
