INSERT INTO joueurEquipes (jid, eid) VALUES 
(1,4),
(2,9),
(3,7),
(4,6),
(5,3),
(6,5),
(7,2),
(8,8),
(9,10),
(9,8);

