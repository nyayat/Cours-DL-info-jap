Le fichier utilisateurs.data comporte 500 lignes et est organisé en 18
colonnes séparées par une virgule :
1. le prénom
2. le nom
3. le sexe
4. l'adresse électronique
5. la date de naissance
6. le niveau d'étude, donné par un nombre de 0 à 5 que vous utiliserez comme
   bon vous semble (p.ex. 0=primaire, 1=collège, etc.)
7. l'emploi, donné par un nombre de 0 à 9 que vous utiliserez comme
   bon vous semble (p.ex. 0=étudiant, 1=médecin, etc.)
8. l'opinion politique, donné par un nombre de 0 à 9 (p.ex. 0=sans opinion,
   1=FO, 2=FN, etc.)
9. l'opinion religieuse, donné par un nombre de 0 à 5 (p.ex. 0=athée,
   1=bouddhiste, etc.)
10. le sport pratiqué, donné par un nombre de 0 à 9
11. le numéro et le nom de la rue où habite l'utilisateur
12. le code postal
13. la ville
14. le numéro de téléphone
15. le statut marital, donné par un nombre de 0 à 2 (p.ex. 0=célibataire,
    1=marié, 2=pacsé)
16 à 18. de un à trois hobbies, chacun donné par un nombre de 0 à 9 ; il peut
    y avoir jusqu'à deux colonnes vides sur les trois. Ces hobbies serviront
    notamment à cibler les publicités (voir le fichier publicites.data).


Le fichier commentaires.data comporte 34084 lignes. Chaque ligne contient un
commentaire comprenant entre 3 et 30 caractères.


Le fichier publicites.data comporte 20000 lignes et est organisé en 6 colonnes
séparées par une virgule :
1. le sujet de la publicité ;
2. la marque ;
3. le slogan publicitaire ;
4 à 6. des mots-clés concernant le sujet. A chaque
  sujet est associé un à trois mots-clés, et donc les deux dernières colonnes
  peuvent ne pas contenir de données. Ces mots-clés concernent les 10 hobbies
  utilisés dans le fichier utilisateurs.data, et également 'parent' pour
  cibler les utilisateurs qui ont des enfants.

Vous pourrez compléter les données du fichier publicites.data par les
caractéristiques des publicités mentionnées dans le sujet.



Le fichier photos.zip est une archive contenant 100 photos de taille
214x314px, nommées de 1.jpg à 100.jpg, que vous pouvez utiliser pour les
comptes utilisateurs.

