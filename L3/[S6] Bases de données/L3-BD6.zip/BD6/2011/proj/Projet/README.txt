Le fichier data.csv contient toutes les données.  Chaque ligne du fichier 
correspond à une entrée.  Les colonnes sont délimitées par un "|".  La première 
colonne indique le type d’entrée.  Il y a 6 valeurs : 10, 20, 30, 40, 50 et 60.
  
Les détails pour chaque type ce retrouve ci-dessous.

Comme indiqué dans les instructions du projet, ces données ne doivent pas 
servir comme modèle pour votre propre base de données.
 
Type 10 -- Emballeur (5 entrées)
Col      Description
1        10
2        Numéro d’emballeur
3        Nom
4        Prénom
5        Taux d’erreur
6        Mot de passe
 
Type 20 -- Client (100 entrées)
Col      Description
1    	 20
2        Numéro du client
3        Nom de la société
4        Suffixe de la société
5        Adresse
6        Ville
7        Code postale
8        Pays
9        Téléphone
10       Mot de passe
 
Type 30 -- Produit (2000 entrées)
Col      Description
1        30
2        Numéro du produit
3        Description du produit
4        Quantité par carton
5        Cartons par palette
6        Qualifiant :
                        N : S/O
                        D : Dangereux
                        F : Fragile
7        Coût
8        Taux d’augmentation de prix
9        Poids
10       Réserve
 
Type 40 -- Transporteurs (10 entrées)
Col      Description
1        40
2        Code SCAC (ID unique)
3        Nom de transporteur
4        Mot de passe
 
Type 50 -- Douane (6 entrées)
Col      Description
1        50
2        Pays
3        Taux de colis vérifié
4        Login
5        Mot de passe
 
Type 60 -- Gérant (1 entrée)
Col      Description
1        60
2        Prénom
3        Nom
4        Login
5        Mot de passe
