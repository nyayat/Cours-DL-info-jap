DROP TABLE restaurant CASCADE;
DROP TABLE personne CASCADE;
DROP TABLE qualification CASCADE;
DROP TABLE sait_faire CASCADE;
DROP TABLE contrat CASCADE;

CREATE TABLE personne(
	id_perso serial primary key,
	nom varchar not null,
	prenom varchar not null,
	adresse varchar not null,
	genre varchar check(genre IN ('H','F')),
  unique (nom,prenom)
);


CREATE TABLE restaurant(
	id_resto serial primary key,
	nom varchar Not null unique,
	type_cuis varchar 
    check (type_cuis IN('francaise', 'chinoise', 'indienne', 'japonaise')),
	id_pro int references personne(id_perso) on update cascade on delete set null
);


CREATE TABLE qualification(
	qualif varchar,
	primary key(qualif)
);

CREATE TABLE sait_faire(
	id_perso int not null references personne(id_perso)
            on update cascade on delete cascade,
	qualif varchar not null references qualification(qualif)
            on update cascade on delete cascade,
	primary key(id_perso,qualif)
);

CREATE TABLE contrat(
	id_perso int not null REFERENCES personne(id_perso) 
		on update cascade on delete cascade,
	id_resto int not null REFERENCES restaurant(id_resto)
		on update cascade on delete cascade,
	affect varchar not null references qualification(qualif)
		on update cascade on delete set null,
	primary key(id_perso, id_resto, affect)
);
	
INSERT INTO personne(nom, prenom, adresse,genre) VALUES
('nom1','prenom1','ville1','F'),
('nom2','prenom2','ville2','H'),
('nom3','prenom3','ville3','H'),
('nom4','prenom4','ville4','F'),
('nom5','prenom5','ville5','F'),
('nom6','prenom6','ville6','F'),
('nom7','prenom7','ville7','H');
INSERT INTO restaurant(nom,type_cuis,id_pro) VALUES
('resto1', 'chinoise',6),
('resto2', 'francaise',4),
('resto3','japonaise',6),
('resto4', 'indienne',7),
('resto5', 'indienne',7)
;
INSERT INTO qualification(qualif) VALUES 
('serveur'),
('cuisinier');
INSERT INTO sait_faire(id_perso,qualif) VALUES
 (1,'cuisinier'),
 (2,'cuisinier'),
 (3,'serveur'),
 (4,'serveur'),
 (5,'cuisinier'),
 (6,'cuisinier'),
 (7,'serveur'); 
INSERT INTO contrat(id_perso,id_resto,affect) VALUES 
(1,1,'serveur'),
(1,1,'cuisinier'),
(2,1,'serveur'),
(2,1,'cuisinier'),
(3,2,'serveur'),
(4,2,'cuisinier'),
(5,2,'cuisinier'),
(5,3,'cuisinier'),
(5,3,'serveur'),
(7,4,'serveur'),
(7,1,'serveur'),
(7,5,'serveur')
;
