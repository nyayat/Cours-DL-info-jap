
public interface Sequencable {
	// Renvoie la longueur de la sequence
	public int longeur();

	// Renvoie le ieme objet de la sequence
	public Comparable contenu(int i);

	// affiche la sequence
	default void affiche() {
		String s=contenu(1).toString();
		for(int i=2; i< longeur(); i++) {
			s+=", " + contenu(i).toString();
		}
		System.out.println("[" + s + "]");
	}
	

	// Echange le ieme object avec le jieme objet
	public void echange(int i, int j);
	
	//Tri la sequence
	default void triBulle() {
		boolean change = false;
		do {
			change = false;
			for (int i = 1; i < longeur()-1; i++) {
				if ( contenu(i).estPlusGrand(contenu(i+1))) {
					echange(i, i+1);
					change = true;
				}
			}
		} while (change);

	}
}
