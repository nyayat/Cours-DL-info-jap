
public class SequenceEntier implements Sequencable {

	EntierComparable[] tab;
	int length;

	public SequenceEntier(int k) {
		this.length = k;
		this.tab = new EntierComparable[k];
		for(int i=0; i < k ; i++ ) {
			this.tab[i]= new EntierComparable((int)(Math.random()*30));
		}
	}

	public void set(int i, EntierComparable v) {
		this.tab[i - 1] = v;
	}

	@Override
	public int longeur() {
		// TODO Auto-generated method stub
		return this.length;
	}

	@Override
	public void echange(int i, int j) {
		EntierComparable tmp = tab[i];
		tab[i] = tab[j];
		tab[j] = tmp;
	}

	@Override
	public Comparable contenu(int i) {
		return this.tab[i];
	}

}
