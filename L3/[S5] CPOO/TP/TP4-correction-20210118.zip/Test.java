
public class Test {

	public static void main(String[] args) {
		SequenceMots S = new SequenceMots(15);
		S.affiche();
		S.triBulle();
		S.affiche();
	}
}
