
public class EntierComparable implements Comparable {

	int v;

	public EntierComparable(int k) {
		this.v = k;
	}
	
	public String toString() {
		return value().toString();
	}
	@Override
	public Object value() {
		return v;
	}

	@Override
	public boolean estPlusGrand(Comparable other) {
		if ((other.value() instanceof Integer)) {
			return v > (int) other.value();

		} else

		{
			throw new Error();
		}
	}

	public void set(int i) {
		this.v = i;
	}
}
