
public interface Comparable {

	public boolean estPlusGrand(Comparable i);
	
	default String affiche() {
		return value().toString();
	}

	public Object value();
}
