
public class MotsComparable  implements Comparable {

	String v;

	public MotsComparable(String k) {
		this.v = k;
	}
	
	public String toString() {
		return this.v;
	}
	@Override
	public Object value() {
		return this.v;
	}

	@Override
	public boolean estPlusGrand(Comparable other) {
		if ((other.value() instanceof String)) {
			return v.compareTo( (String) other.value()) > 0 ;

		} else

		{
			throw new Error();
		}
	}

	public void set(String i) {
		this.v = i;
	}

}
