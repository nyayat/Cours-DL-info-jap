
public class SequenceMots implements Sequencable {

	int length;
	MotsComparable[] tab;
	
	public SequenceMots(int k) {
		this.length=k;
		this.tab= new MotsComparable[k];
		for(int i=0;i<k;i++) {
			tab[i]= new MotsComparable(Integer.toString((int)(Math.random()*50000)));
		}	
	}
	@Override
	public int longeur() {
		return length;
	}

	@Override
	public Comparable contenu(int i) {
		return tab[i];
	}

	@Override
	public void echange(int i, int j) {
		MotsComparable tmp = tab[i];
		tab[i]=tab[j];
		tab[j]=tmp;
	}

}
