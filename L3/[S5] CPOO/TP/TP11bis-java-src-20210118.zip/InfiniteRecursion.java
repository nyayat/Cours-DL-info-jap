public class InfiniteRecursion {
    public static void incr(int n) {
        System.out.println(n);
        incr(1 + n);
    }

    public static void main(String[] args) {
        incr(0);
    }
}