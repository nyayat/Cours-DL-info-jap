package up.cpoo.concurrent;
import java.util.concurrent.CompletableFuture;
import static java.util.concurrent.CompletableFuture.*;
import java.util.function.*;

public final class CompletableFutureTools {
    private CompletableFutureTools() {}

    /*
	 * Méthode manquante dans l'API CompletableFuture, pourtant très utile pour ce genre 
	 * d'exercice. Elle prend en paramètre une fonction construisant un CompletableFuture
	 * et retourne un CompletableFuture qui devra retourner la même valeur que celui
	 * qui est retourné par la fonction...
	 * ... mais jamais supplyAndFlatten ne demande l'exécution de la tâche associée.
	 * Ainsi, elle ne sera exécutée que lorsqu'on appellera join.
	 */
	public static <T> CompletableFuture<T> supplyAndFlatten(Supplier<CompletableFuture<T>> fn) {
		return supplyAsync(fn).thenCompose(x -> x);
		// (plus ou moins équivalent à:) return completedFuture(null).thenComposeAsync(x -> fn.get());
	}

}