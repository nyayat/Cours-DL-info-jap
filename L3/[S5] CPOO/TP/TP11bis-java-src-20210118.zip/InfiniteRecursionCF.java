import static java.util.concurrent.CompletableFuture.*;

import java.util.concurrent.CompletableFuture;

public class InfiniteRecursionCF {
    public static CompletableFuture<Void> incr(int n) {
        System.out.println(n);
        return completedFuture(n+1).thenComposeAsync(InfiniteRecursionCF::incr);
    }

    public static void main(String[] args) {
        incr(0).join();
    }
}