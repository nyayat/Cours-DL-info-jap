import java.util.concurrent.CompletableFuture;
import static java.util.concurrent.CompletableFuture.*;
import static up.cpoo.concurrent.CompletableFutureTools.*;

public class FiboCF {

	public static CompletableFuture<Integer> calculFibo(int n) {
		if (n <= 1)
			return completedFuture(1);
		else {
			CompletableFuture<Integer> f1 = supplyAndFlatten(() -> calculFibo(n - 1));
			CompletableFuture<Integer> f2 = supplyAndFlatten(() -> calculFibo(n - 2));
			return f1.thenCombine(f2, (x, y) -> x + y);
		}
	}

	public static void main(String[] args) {
		System.out.println(calculFibo(30).join());
	}

}
