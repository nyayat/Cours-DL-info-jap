import java.util.concurrent.Flow.*;
import java.util.concurrent.SubmissionPublisher;
import java.util.function.*;

public class FanInProcessor<U, V, R> implements Publisher<R>, AutoCloseable {
    public class FanInSubscriber<T> implements Subscriber<T> {
        private final Consumer<T> store;
        private Subscription subscription;

        public FanInSubscriber(Consumer<T> store) {
            this.store = store;
        }

        @Override
        public void onSubscribe(Subscription subscription) {
            this.subscription = subscription;
            subscription.request(1);
        }

        @Override
        public void onNext(T message) {
            synchronized (FanInProcessor.this) {
                store.accept(message);
                tryProcessNext();
            }
        }

        @Override
        public void onError(Throwable arg0) {
        }

        @Override
        public void onComplete() {
        }

    }

    public final FanInSubscriber<U> leftInput = new FanInSubscriber<>(message -> {
        lastLeft = message;
    });

    public final FanInSubscriber<V> rightInput = new FanInSubscriber<>(message -> {
        lastRight = message;
    });

    private U lastLeft; // null quand dernière donnée disponible déjà consommée
    private V lastRight; // null quand dernière donnée disponible déjà consommée
    private final SubmissionPublisher<R> output = new SubmissionPublisher<>();
    private final BiFunction<U, V, R> transform;

    @Override
    public void subscribe(Subscriber<? super R> subscriber) {
        output.subscribe(subscriber);
    }

    @Override
    public void close() {
        output.close();
    }

    private void tryProcessNext() {
        if (lastLeft == null || lastRight == null)
            return; // la source en avance s'arrête là et ne fait rien de particulier
        output.submit(transform.apply(lastLeft, lastRight));
        lastLeft = null;
        lastRight = null;
        leftInput.subscription.request(1);
        rightInput.subscription.request(1);
    }

    public FanInProcessor(BiFunction<U, V, R> transform) {
        this.transform = transform;
    }

}
