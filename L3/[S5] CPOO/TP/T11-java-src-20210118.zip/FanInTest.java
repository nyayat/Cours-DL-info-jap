import java.util.concurrent.SubmissionPublisher;
import static java.util.stream.Stream.of;
import static java.util.concurrent.ForkJoinPool.commonPool;
import static java.util.concurrent.TimeUnit.MILLISECONDS;

public class FanInTest {
    public static void main(String[] args) throws InterruptedException {
        try (var source1 = new SubmissionPublisher<Integer>();
                var source2 = new SubmissionPublisher<Integer>();
                var multiplicator = new FanInProcessor<Integer, Integer, Integer>((a, b) -> a * b)) {
            // 1. on construit l'application
            source1.subscribe(multiplicator.leftInput);
            source2.subscribe(multiplicator.rightInput);
            multiplicator.subscribe(new PrintSubscriber<>());
            // 2. on l'alimente avec des données
            of(34, 1234, 123, 12, 98, 93).forEach(source1::submit); // première série de données
            of(49, 34, 313, 132, 898, 293).forEach(source2::submit); // deuxième série de données
            // 3. on attend que ça se termine
            commonPool().awaitTermination(1000, MILLISECONDS);
        } // les ressources sont fermées en sortant du try-with-resource
    }
}
