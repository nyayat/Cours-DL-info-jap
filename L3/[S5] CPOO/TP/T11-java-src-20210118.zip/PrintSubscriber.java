import java.util.concurrent.Flow.*;

public class PrintSubscriber<T> implements Subscriber<T> {
    private Subscription subscription;

    @Override
    public void onSubscribe(Subscription subscription) {
        this.subscription = subscription;
        subscription.request(1);
    }

    @Override
    public void onNext(T message) {
        subscription.request(1);
        System.out.println(message);
    }

    @Override
    public void onError(Throwable arg0) {
    }

    @Override
    public void onComplete() {
    }
}
