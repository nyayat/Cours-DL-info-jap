package cartes;

import java.awt.Color;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class Carte {
    // Classe à constructeur privé, plutôt qu'interface : on impose que les instances de Carte soient toutes instances des classes imbriquées de Carte (-> concept de classe scellée).
    // Par ailleurs le type Carte est ainsi immuable.
    private Carte() {}

    public enum Enseigne {
        CARREAU(Color.RED), COEUR(Color.RED), PIQUE(Color.BLACK), TREFLE(Color.BLACK);

        private final Color vraieCouleur;

        private Enseigne(Color vraieCouleur) {
            this.vraieCouleur = vraieCouleur;
        }

        public Color getVraieCouleur() {
            return vraieCouleur;
        }
    }

    public enum Valeur {
        AS, CINQ, DAME, DEUX, DIX, HUIT, NEUF, QUATRE, ROI, SEPT, SIX, TROIS, VALET;
        public boolean estFigure() {
            switch (this) {
            case VALET:
            case DAME:
            case ROI:
                return true;
            default:
                return false;
            }
        }
    }

    public enum DessinJoker {
        DESSIN1, DESSIN2
    }

	public static final class CarteValeurEnseigne extends  Carte {
		public final Enseigne enseigne;
		public final Valeur valeur;

		public CarteValeurEnseigne(Valeur v, Enseigne e) {
			this.valeur = v;
			this.enseigne = e;
		}

		public boolean estFigure() {
			return valeur.estFigure();
		}

		@Override
		public String toString() {
			return valeur + " de " + enseigne;
		}

		public int getValeurNumerique() {
			return valeur.ordinal();
		}

		public Color getVraieCouleur() {
			return enseigne.getVraieCouleur();
		}

	}

	public static final class Joker extends Carte {
		public static List<Joker> nouvellePaire() {
			return Arrays.asList(new Joker[] { new Joker(DessinJoker.DESSIN1), new Joker(DessinJoker.DESSIN2) });
		}

		public final DessinJoker dessin;

		public Joker(DessinJoker dessin) {
			this.dessin = dessin;
		}
	}

	public static List<CarteValeurEnseigne> nouveauJeu52() {
		List<CarteValeurEnseigne> jeu = new LinkedList<>();
		for (Enseigne c : Enseigne.values())
			for (Valeur v : Valeur.values())
				jeu.add(new CarteValeurEnseigne(v, c));
		return Collections.unmodifiableList(jeu);
	}

	public static List<Carte> nouveauJeu54() {
		List<Carte> jeu = new LinkedList<>();
		jeu.addAll(nouveauJeu52());
		jeu.addAll(Joker.nouvellePaire());
		return Collections.unmodifiableList(jeu);
	}

}
