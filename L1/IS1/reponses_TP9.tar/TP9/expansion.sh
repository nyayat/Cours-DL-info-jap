echo "Le chemin absolu de mon répertoire courant est $PWD 
Le résultat de la commande whoami est $(whoami)
Le produit de 33 par 17 vaut $((33*17))
Il a agi " anti{constitutionel,conventionnel,socia}lement

