echo "Bonjour, $NOM"

NOM=Tartempion

echo "Bonjour, $NOM"
