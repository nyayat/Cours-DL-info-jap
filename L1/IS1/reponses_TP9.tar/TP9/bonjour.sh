echo "Je dois saluer $# personnes"

echo "Bonjour "$@" "
