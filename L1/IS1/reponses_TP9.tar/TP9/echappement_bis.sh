TOTO=whoami

echo "J’aime bien utiliser la commande "$TOTO"."
echo "Ma variable" '$TOTO' "contient '$TOTO'."
echo "Mon login est $($TOTO)
La commande d’aujourd’hui est" '\'"$TOTO"'\'".
${TOTO:0:3}areyou, c’est une commande imaginaire !"
