echo "A     B
L’ensemble {1, 2, 3} est inclus dans N.
Elle demanda d’une voix *forte* : \"Qui est-ce ?\""

echo '$HOME = ${HOME}'" = $HOME"

echo "19 * 216 = $((19*216))
Ajoutez un peu d’huile d’olive, d’humeur joyeuse, d’humus, et remuez bien !"
