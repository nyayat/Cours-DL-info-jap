<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
</head>
<body>
<h2>
Produits ajoutés aux favoris :
<?php 
$prod = $_POST['prod'];
if (isset($prod)) {
	foreach ($prod as $p) {
		echo $p; echo " ";
	}
}

?>
</h2>
</body>
</html>