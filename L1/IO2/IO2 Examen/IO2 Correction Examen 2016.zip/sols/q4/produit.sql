create table Produit (
id int primary key,
nom VARCHAR (100),
image VARCHAR (30),
description TEXT,
prix decimal(6,2)
)


insert into Produit values 
(1, 'Playing Cube', 'prod1.jpg', 'Texte Texte...', 15),
(2, 'Cooking set', 'prod2.jpg', 'Texte..', 125);
(3, 'Pomme', 'prod3.jpg', 'Texte...', 1.50);


