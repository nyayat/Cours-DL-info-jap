<?php
require_once "affichage.php";


function connexion_bd() {
	$serv ="127.0.0.1";
	$username = "sirangelo";
	$pwd = "sirangelo";
	$bd ="io2017";
	$connex = mysqli_connect($serv, $username, $pwd, $bd);	
	if (! $connex) {
    	page_erreur(ERR_CONNEX, mysqli_connect_error($connex)); exit; 
	}
	return $connex;
}

function lire_produits($connex) {
	$req = "select * from Produit";
	$resultat = mysqli_query($connex, $req);
	if (!$resultat) {
		page_erreur(ERR_REQUETE, mysqli_error($connex)); 
		mysqli_close($connex);
		exit;
	}
	return $resultat;	
}

function lire_favoris($connex, $user) {
	$req = "select * from Produit, Favoris where prod = id and util = '$user'";
	$resultat = mysqli_query($connex, $req);
	if (!$resultat) {
		page_erreur(ERR_REQUETE, mysqli_error($connex)); 
		mysqli_close($connex);
		exit;
	}
	return $resultat;	
}

function ajouter_favoris ($connex, $prod, $login) {
	
	$req = "insert into Favoris values ";
	for ($i = 0; $i < count($prod); $i++) {
		if ($i>0) $req.=",";
		$req = $req."('".$login."',".$prod[$i].")";
	}
	$resultat = mysqli_query($connex, $req);
	if (!$resultat) {
		page_erreur(ERR_REQUETE, mysqli_error($connex)); 
		mysqli_close($connex);
		exit;
	}
	return $resultat;

}

?>