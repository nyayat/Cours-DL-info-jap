<?php
require_once "affichage.php";
require_once "connex.php";

$connex = connexion_bd();

$prods = lire_produits($connex);

page_produits($prods);

mysqli_free_result($prods);

mysqli_close($connex);

?>

