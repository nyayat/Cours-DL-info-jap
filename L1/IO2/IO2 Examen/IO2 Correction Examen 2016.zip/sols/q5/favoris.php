<?php
require_once "affichage.php";
require_once "connex.php";

$connex = connexion_bd();

$prods = lire_favoris($connex, 'user0');

page_favoris($prods);

mysqli_free_result($prods);

mysqli_close($connex);

?>

