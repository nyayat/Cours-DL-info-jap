<?php
require_once "affichage.php";
require_once "connex.php";

$connex = connexion_bd();

$prod = $_POST['prod'];
if (isset($prod)) 
	ajouter_favoris ($connex, $prod, 'user0');

page_ajout();
?>