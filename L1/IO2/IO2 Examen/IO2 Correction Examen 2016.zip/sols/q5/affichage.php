<?php

//le codes d'erreurs, pour savoir quel type d'erreur afficher
define('ERR_CONNEXION', 0);
define ('ERR_REQUETE', 1);


//les fonctions de base pour  l'affichage
function afficher_entete($titre) { 
?>
	<html>
	<head> 
	<title> <?=$titre?> </title> 
	<meta charset="utf-8" >
	<style>
		img { width:100px; height:100px}
	</style>	
	</head>
	<body>
<?php 
}

function afficher_pied_page() {
	echo "</body></html>";
}

//affiche un produit
//parametre : un tableau associatif representant un produit
//noter la protection des chaines avant l'affichage
function afficher_ligne(&$ligne) { 
	$id = $ligne["id"];
	$img_file = $ligne["image"];
?>
	<div>
	<input type="checkbox" name="prod[]" value="<?= $id ?>">
  	<img src = "<?= $img_file ?>">
<?
	echo "<p>".htmlspecialchars($ligne["nom"])."</p>",
		"<p>".htmlspecialchars($ligne["description"])."</p>",
		"<p>".htmlspecialchars($ligne["prix"])."</p>",
		"</div> 
		<hr>";
}


//les vues

//la page qui affiche les produits disponibles
//parametre : la ressource contenant les produits à afficher
function page_produits ($prods) { 
	afficher_entete("Produits");
?>
	<form action="ajouter2.php" method="post">
<?
	while($ligne = mysqli_fetch_assoc($prods)) afficher_ligne($ligne);	
?>
<input type="submit" value="Ajouter aux favoris" name="go">
</form> 

<form action ="favoris.php" method ="get">
<input type="submit" value="Visualiser les favoris" name="fav">
</form>
<?
	afficher_pied_page();
}


//la page qui affiche la confirmation d'ajout
function page_ajout () { 
	afficher_entete("Ajout");
	echo "<h2> Produits ajoutés aux favoris ! </h2>";
	afficher_pied_page();
}

//la page qui affiche les favoris d'un utilisateur
//parametre : la ressource contenant les produits à afficher
function page_favoris ($prods) { 
	afficher_entete("Favoris");
?>
	<h2> Favoris </h2>
	<form action="supprimer.php" method="post">
<?
	while($ligne = mysqli_fetch_assoc($prods)) afficher_ligne($ligne);	
?>
<input type="submit" value="Supprimer (pas implementé)" name="go">
</form> 
<?
}


//affiche une page d'erreur
//paramteres : le code de l'erreur et un message d'erreur
function page_erreur($err_code, $error) {
	afficher_entete("Erreur");
	switch ($err_code) {
		case ERR_CONNEXION:
			echo "<h2>Desolé, connexion impossible</h2>";
			break;
		case ERR_REQUETE:
			echo "<h2>Erreur dans l'execution de la requete</h2>";
			break;
	}
	//pour le deboggage :
	echo "<p>".$error."</p>";
	afficher_pied_page();
}
?>



