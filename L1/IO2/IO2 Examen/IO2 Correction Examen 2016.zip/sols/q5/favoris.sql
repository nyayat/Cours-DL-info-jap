
create table Utilisateur (
login VARCHAR (30)primary key,
nom VARCHAR (50),
mdp VARCHAR (20)
);
create table Favoris (
util varchar(30),
prod int,
primary key (util, prod),
foreign key (util) references Utilisateur(login),
foreign key (prod) references Produit(id)
);
insert into Utilisateur values 
('user0', 'cristina', 's3cr3t'),
('user1', 'jean', 'g00d');